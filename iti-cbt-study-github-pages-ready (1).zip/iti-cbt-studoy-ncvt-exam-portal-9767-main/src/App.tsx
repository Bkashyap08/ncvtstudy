import React, { useState } from 'react';
import { Navbar, NavTab } from './components/Navbar';
import { DashboardView } from './components/DashboardView';
import { PracticeMode } from './components/PracticeMode';
import { QuestionBankBrowser } from './components/QuestionBankBrowser';
import { CheatsheetsView } from './components/CheatsheetsView';
import { CbtExamEngine } from './components/CbtExamEngine';
import { ExamResultView } from './components/ExamResultView';
import { ExamLauncherModal } from './components/ExamLauncherModal';
import { TradeId, ExamConfig, ExamResult, Question, Language } from './types';
import { TRADES } from './data/trades';
import { QUESTIONS_BANK } from './data/questions';
import { generateExamQuestions } from './utils/examGenerator';
import { saveExamResult, getStoredSettings, saveSettings } from './utils/storage';

export default function App() {
  const initialSettings = getStoredSettings();

  const [currentTab, setCurrentTab] = useState<NavTab>('dashboard');
  const [selectedTrade, setSelectedTrade] = useState<TradeId>(initialSettings.tradeId);
  const [selectedYear, setSelectedYear] = useState<1 | 2>(initialSettings.year);
  const [studentName, setStudentName] = useState<string>(initialSettings.studentName);
  const [rollNumber, setRollNumber] = useState<string>(initialSettings.rollNumber);
  const [examLanguage, setExamLanguage] = useState<Language>(initialSettings.language);

  // Active Exam state
  const [activeExamConfig, setActiveExamConfig] = useState<ExamConfig | null>(null);
  const [activeExamQuestions, setActiveExamQuestions] = useState<Question[] | null>(null);

  // Result state
  const [activeResult, setActiveResult] = useState<ExamResult | null>(null);
  const [activeResultQuestions, setActiveResultQuestions] = useState<Question[] | null>(null);

  // Launcher modal
  const [isLauncherOpen, setIsLauncherOpen] = useState<boolean>(false);
  const [launcherTrade, setLauncherTrade] = useState<TradeId>(initialSettings.tradeId);

  // Handlers
  const handleOpenLauncher = (tradeId?: TradeId) => {
    if (tradeId) setLauncherTrade(tradeId);
    setIsLauncherOpen(true);
  };

  const handleStartExam = (
    config: ExamConfig,
    candidateInfo: { name: string; roll: string; lang: Language }
  ) => {
    // Generate questions for this exam
    const questions = generateExamQuestions(config);

    setSelectedTrade(config.tradeId);
    setSelectedYear(config.year);
    setStudentName(candidateInfo.name);
    setRollNumber(candidateInfo.roll);
    setExamLanguage(candidateInfo.lang);

    saveSettings({
      tradeId: config.tradeId,
      year: config.year,
      language: candidateInfo.lang,
      studentName: candidateInfo.name,
      rollNumber: candidateInfo.roll
    });

    setActiveExamConfig(config);
    setActiveExamQuestions(questions);
    setActiveResult(null);
    setIsLauncherOpen(false);
  };

  const handleFinishExam = (result: ExamResult) => {
    saveExamResult(result);
    setActiveResult(result);
    setActiveResultQuestions(activeExamQuestions);
    setActiveExamQuestions(null);
    setActiveExamConfig(null);
  };

  const handleExitExam = () => {
    setActiveExamQuestions(null);
    setActiveExamConfig(null);
  };

  const handleReviewPastResult = (pastResult: ExamResult) => {
    // Collect questions matching answer records or fall back to questions bank
    const questions = pastResult.answers
      .map(a => QUESTIONS_BANK.find(q => q.id === a.questionId.split('-dup-')[0].split('-rep-')[0]))
      .filter(Boolean) as Question[];

    setActiveResult(pastResult);
    setActiveResultQuestions(questions.length > 0 ? questions : QUESTIONS_BANK.slice(0, pastResult.totalQuestions));
    setActiveExamQuestions(null);
  };

  // If exam is currently running, render full-screen CBT simulation without standard header
  if (activeExamQuestions && activeExamConfig) {
    const tradeInfo = TRADES.find(t => t.id === activeExamConfig.tradeId) || TRADES[0];
    return (
      <CbtExamEngine
        questions={activeExamQuestions}
        tradeName={tradeInfo.name.en}
        tradeCode={tradeInfo.code}
        year={activeExamConfig.year}
        studentName={studentName}
        rollNumber={rollNumber}
        initialTimeMinutes={activeExamConfig.timeMinutes}
        initialLanguage={examLanguage}
        onFinishExam={handleFinishExam}
        onExitExam={handleExitExam}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      {/* Universal 3-zone Header Contract */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={tab => {
          setActiveResult(null);
          setCurrentTab(tab);
        }}
        onStartNewExam={() => handleOpenLauncher(selectedTrade)}
        isExamActive={false}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {/* If viewing an exam result */}
        {activeResult && activeResultQuestions ? (
          <ExamResultView
            result={activeResult}
            questions={activeResultQuestions}
            onRetake={() => {
              setActiveResult(null);
              handleOpenLauncher(activeResult.tradeId);
            }}
            onGoHome={() => {
              setActiveResult(null);
              setCurrentTab('dashboard');
            }}
          />
        ) : currentTab === 'dashboard' ? (
          <DashboardView
            onStartExam={tId => handleOpenLauncher(tId || selectedTrade)}
            onNavigateToPractice={tId => {
              setSelectedTrade(tId);
              setCurrentTab('practice');
            }}
            onNavigateToBank={() => setCurrentTab('bank')}
            onReviewPastResult={handleReviewPastResult}
          />
        ) : currentTab === 'mock_test' ? (
          <div className="max-w-4xl mx-auto px-4 py-12 text-center">
            <div className="bg-white p-8 md:p-12 rounded-2xl border border-slate-200 shadow-sm max-w-2xl mx-auto">
              <div className="w-16 h-16 rounded-2xl bg-slate-900 text-white flex items-center justify-center font-bold text-xl mx-auto mb-4 shadow">
                CBT
              </div>
              <h1 className="text-2xl font-bold text-slate-900">
                Official NCVT CBT Mock Test Center
              </h1>
              <p className="text-sm text-slate-600 mt-2 leading-relaxed">
                Experience the authentic All India Trade Test (AITT) examination with official question formats, section timers, question palettes, and immediate answer analysis.
              </p>

              <div className="grid grid-cols-2 gap-3 text-left my-6 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
                <div>
                  <span className="text-slate-500">Pattern:</span> <strong className="text-slate-900">DGT AITT Standard</strong>
                </div>
                <div>
                  <span className="text-slate-500">Bilingual:</span> <strong className="text-slate-900">English + हिन्दी</strong>
                </div>
                <div>
                  <span className="text-slate-500">Passing:</span> <strong className="text-emerald-700">33% Minimum</strong>
                </div>
                <div>
                  <span className="text-slate-500">Marking:</span> <strong className="text-slate-900">+2 Marks, No Neg.</strong>
                </div>
              </div>

              <button
                onClick={() => handleOpenLauncher(selectedTrade)}
                className="w-full py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm shadow-md transition-colors cursor-pointer"
              >
                Configure & Start Mock Test →
              </button>
            </div>
          </div>
        ) : currentTab === 'practice' ? (
          <PracticeMode
            initialTradeId={selectedTrade}
            initialYear={selectedYear}
            onStartExamFromTrade={(tId, yr) => {
              setSelectedTrade(tId);
              setSelectedYear(yr);
              handleOpenLauncher(tId);
            }}
          />
        ) : currentTab === 'bank' ? (
          <QuestionBankBrowser />
        ) : currentTab === 'cheatsheet' ? (
          <CheatsheetsView />
        ) : null}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-6 mt-12 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-800">ITI CBT Study Portal</span>
            <span aria-hidden="true">·</span>
            <span>Based on NCVT / DGT / Bharat Skills NIMI Curriculum</span>
          </div>
          <div className="text-slate-400">
            For ITI CTS Examination Preparation · All Rights Reserved
          </div>
        </div>
      </footer>

      {/* Exam Launcher Dialog */}
      <ExamLauncherModal
        isOpen={isLauncherOpen}
        onClose={() => setIsLauncherOpen(false)}
        onStartExam={handleStartExam}
        defaultTradeId={launcherTrade}
        defaultYear={selectedYear}
      />
    </div>
  );
}
