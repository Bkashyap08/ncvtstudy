export type Language = 'en' | 'hi' | 'bilingual';

export type TradeId = 'electrician' | 'fitter' | 'copa' | 'electronic_mechanic' | 'welder';

export type SubjectCategory = 'trade_theory' | 'workshop_calc' | 'engineering_drawing' | 'employability_skills';

export interface BilingualText {
  en: string;
  hi: string;
}

export interface QuestionOption {
  id: 'A' | 'B' | 'C' | 'D';
  text: BilingualText;
}

export interface Question {
  id: string;
  tradeId: TradeId | 'common_all' | 'common_engineering';
  year: 1 | 2;
  subjectCategory: SubjectCategory;
  module: string;
  moduleHi: string;
  question: BilingualText;
  options: QuestionOption[];
  correctOption: 'A' | 'B' | 'C' | 'D';
  explanation: BilingualText;
  diagramType?: 'circuit' | 'vernier' | 'micrometer' | 'welding_joint' | 'logic_gate' | 'transformer' | 'drawing_projection' | 'safety_sign';
  diagramData?: {
    caption: BilingualText;
    svgContent?: string;
  };
  difficulty: 'easy' | 'medium' | 'hard';
  source?: string; // e.g. "NIMI Question Bank 2024 / Bharat Skills"
}

export interface TradeInfo {
  id: TradeId;
  name: BilingualText;
  code: string;
  durationYears: 1 | 2;
  iconName: string;
  color: string;
  description: BilingualText;
  totalModules: number;
}

export type QuestionAttemptStatus = 'not_visited' | 'not_answered' | 'answered' | 'marked_for_review' | 'answered_marked';

export interface UserAnswerRecord {
  questionId: string;
  selectedOption?: 'A' | 'B' | 'C' | 'D';
  status: QuestionAttemptStatus;
  timeSpentSeconds: number;
}

export interface ExamConfig {
  tradeId: TradeId;
  year: 1 | 2;
  mode: 'full_cbt' | 'quick_mock' | 'subject_test';
  subjectCategory?: SubjectCategory;
  totalQuestions: number;
  timeMinutes: number;
  passPercentage: number;
}

export interface ExamResult {
  id: string;
  date: string;
  tradeId: TradeId;
  tradeName: string;
  year: 1 | 2;
  mode: string;
  totalQuestions: number;
  attemptedQuestions: number;
  correctAnswers: number;
  incorrectAnswers: number;
  score: number;
  maxScore: number;
  percentage: number;
  isPassed: boolean;
  timeTakenSeconds: number;
  answers: UserAnswerRecord[];
  categoryBreakdown: {
    category: SubjectCategory;
    total: number;
    correct: number;
    percentage: number;
  }[];
}

export interface BookmarkedQuestion {
  questionId: string;
  addedAt: string;
  notes?: string;
}
