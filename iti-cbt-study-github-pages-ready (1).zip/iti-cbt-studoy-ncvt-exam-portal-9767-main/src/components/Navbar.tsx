import React from 'react';

export type NavTab = 'dashboard' | 'mock_test' | 'practice' | 'bank' | 'cheatsheet';

interface NavbarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  onStartNewExam: () => void;
  isExamActive: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  onStartNewExam,
  isExamActive
}) => {
  return (
    <header className="border-b border-slate-200 bg-white sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand title, one line */}
        <div 
          onClick={() => !isExamActive && onSelectTab('dashboard')} 
          className="cursor-pointer flex items-center gap-2 whitespace-nowrap shrink-0"
        >
          <span className="text-xl font-bold tracking-tight text-slate-900">
            ITI CBT Study
          </span>
          <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 hidden sm:inline-block">
            NCVT · DGT
          </span>
        </div>

        {/* Zone 2: 4-5 nav links, 1-2 word labels, single-line */}
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-600">
          <button
            onClick={() => onSelectTab('dashboard')}
            className={`whitespace-nowrap shrink-0 transition-colors pb-0.5 ${
              currentTab === 'dashboard'
                ? 'text-slate-900 font-semibold border-b-2 border-slate-900'
                : 'hover:text-slate-900'
            }`}
          >
            Dashboard
          </button>
          <button
            onClick={() => onSelectTab('mock_test')}
            className={`whitespace-nowrap shrink-0 transition-colors pb-0.5 ${
              currentTab === 'mock_test'
                ? 'text-slate-900 font-semibold border-b-2 border-slate-900'
                : 'hover:text-slate-900'
            }`}
          >
            Mock Test
          </button>
          <button
            onClick={() => onSelectTab('practice')}
            className={`whitespace-nowrap shrink-0 transition-colors pb-0.5 ${
              currentTab === 'practice'
                ? 'text-slate-900 font-semibold border-b-2 border-slate-900'
                : 'hover:text-slate-900'
            }`}
          >
            Practice
          </button>
          <button
            onClick={() => onSelectTab('bank')}
            className={`whitespace-nowrap shrink-0 transition-colors pb-0.5 ${
              currentTab === 'bank'
                ? 'text-slate-900 font-semibold border-b-2 border-slate-900'
                : 'hover:text-slate-900'
            }`}
          >
            Question Bank
          </button>
          <button
            onClick={() => onSelectTab('cheatsheet')}
            className={`whitespace-nowrap shrink-0 transition-colors pb-0.5 ${
              currentTab === 'cheatsheet'
                ? 'text-slate-900 font-semibold border-b-2 border-slate-900'
                : 'hover:text-slate-900'
            }`}
          >
            Formulas
          </button>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onStartNewExam}
            className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 shadow-sm"
          >
            {isExamActive ? 'Resume Exam' : 'Start Mock CBT'}
          </button>
        </div>
      </div>
    </header>
  );
};
