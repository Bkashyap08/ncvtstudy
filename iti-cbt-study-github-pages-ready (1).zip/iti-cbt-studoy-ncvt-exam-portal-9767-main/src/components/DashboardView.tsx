import React from 'react';
import { TRADES } from '../data/trades';
import { TradeId, ExamResult } from '../types';
import { getStoredResults, getBookmarkedIds } from '../utils/storage';

interface DashboardViewProps {
  onStartExam: (tradeId?: TradeId) => void;
  onNavigateToPractice: (tradeId: TradeId) => void;
  onNavigateToBank: () => void;
  onReviewPastResult: (result: ExamResult) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  onStartExam,
  onNavigateToPractice,
  onNavigateToBank,
  onReviewPastResult
}) => {
  const results = getStoredResults();
  const bookmarkedIds = getBookmarkedIds();

  // Compute metrics
  const totalTests = results.length;
  const passedTests = results.filter(r => r.isPassed).length;
  const passRate = totalTests > 0 ? Math.round((passedTests / totalTests) * 100) : 0;
  const averageScore = totalTests > 0 ? Math.round(results.reduce((acc, r) => acc + r.percentage, 0) / totalTests) : 0;
  const highestScore = totalTests > 0 ? Math.max(...results.map(r => r.percentage)) : 0;

  // Readiness Score
  const examReadiness = Math.min(100, Math.round(averageScore * 0.7 + Math.min(totalTests * 6, 30)));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Hero Banner: All India Trade Test Portal */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 rounded-2xl p-6 md:p-10 text-white shadow-md border border-slate-800">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="max-w-2xl">
            <div className="text-xs uppercase tracking-wider text-amber-400 font-mono mb-2">
              National Council for Vocational Training · Directorate General of Training
            </div>
            <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight">
              AITT Computer Based Test (CBT) Preparation Portal
            </h1>
            <p className="text-slate-300 text-sm mt-2 leading-relaxed">
              Official simulation software for ITI students. Master NIMI & Bharat Skills question banks with real CBT exam timers, question palettes, and bilingual English/हिन्दी testing.
            </p>

            <div className="flex items-center gap-3 mt-6 flex-wrap">
              <button
                onClick={() => onStartExam()}
                className="px-5 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition-all cursor-pointer"
              >
                Launch Official NCVT Mock Test →
              </button>
              <button
                onClick={onNavigateToBank}
                className="px-4 py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-xs border border-slate-700 transition-all cursor-pointer"
              >
                Browse NIMI Question Bank
              </button>
            </div>
          </div>

          {/* Exam Readiness Card */}
          <div className="w-full lg:w-72 bg-slate-800/80 p-5 rounded-xl border border-slate-700/60 shrink-0">
            <div className="text-xs text-slate-400 uppercase tracking-wider font-medium">
              CBT Exam Readiness
            </div>
            <div className="flex items-baseline gap-2 mt-2">
              <span className="text-3xl font-extrabold font-mono text-emerald-400 tabular-nums">
                {totalTests > 0 ? `${examReadiness}%` : 'Not Ready'}
              </span>
              {totalTests > 0 && (
                <span className="text-xs text-slate-400">
                  {examReadiness >= 75 ? 'Well Prepared' : 'Needs Practice'}
                </span>
              )}
            </div>

            {/* Progress bar */}
            <div className="w-full bg-slate-700 h-2 rounded-full mt-3 overflow-hidden">
              <div
                className="bg-emerald-500 h-full rounded-full transition-all duration-500"
                style={{ width: `${Math.max(5, examReadiness)}%` }}
              />
            </div>

            <div className="mt-4 pt-3 border-t border-slate-700 text-[11px] text-slate-400 flex justify-between">
              <span>Tests Completed: <strong className="text-white">{totalTests}</strong></span>
              <span>Pass Rate: <strong className="text-emerald-400">{passRate}%</strong></span>
            </div>
          </div>
        </div>
      </div>

      {/* KPI Metrics Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-xs text-slate-500 font-medium">Mock Tests Attempted</div>
          <div className="text-2xl font-bold font-mono text-slate-900 mt-1 tabular-nums">
            {totalTests}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Full CBT & Quick Mock</div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-xs text-slate-500 font-medium">Average Score</div>
          <div className="text-2xl font-bold font-mono text-slate-900 mt-1 tabular-nums">
            {averageScore}%
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Passing threshold is 33%</div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-xs text-slate-500 font-medium">Highest Score</div>
          <div className="text-2xl font-bold font-mono text-emerald-700 mt-1 tabular-nums">
            {highestScore}%
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Personal Best</div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-xs text-slate-500 font-medium">Bookmarked for Revision</div>
          <div className="text-2xl font-bold font-mono text-amber-700 mt-1 tabular-nums">
            {bookmarkedIds.length}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Saved tricky questions</div>
        </div>
      </div>

      {/* ITI Trades Catalog */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              Select Your Trade
            </h2>
            <p className="text-xs text-slate-500">
              NCVT approved curriculum and questions for 1st & 2nd year CTS trades.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {TRADES.map(t => (
            <div
              key={t.id}
              className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs hover:border-slate-300 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
                  <span className="text-xs font-mono font-semibold text-slate-500">
                    Trade Code: {t.code}
                  </span>
                  <span className="text-xs text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
                    {t.durationYears} {t.durationYears === 1 ? 'Year' : 'Years'}
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900">
                  {t.name.en}
                </h3>
                <div className="text-xs font-devanagari text-slate-600 mb-2">
                  {t.name.hi}
                </div>

                <p className="text-xs text-slate-500 leading-relaxed mb-4">
                  {t.description.en}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                <button
                  onClick={() => onNavigateToPractice(t.id)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  Study & Practice
                </button>
                <button
                  onClick={() => onStartExam(t.id)}
                  className="px-3.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
                >
                  Mock CBT →
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* CBT Exam Structure & Guidelines Info */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-6">
        <h3 className="text-sm font-bold text-slate-900 mb-1">
          Official NCVT AITT Computer Based Examination Blueprint
        </h3>
        <p className="text-xs text-slate-500 mb-4">
          All India Trade Test (AITT) examination pattern issued by DGT (Directorate General of Training).
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs">
          <div className="bg-white p-3.5 rounded-lg border border-slate-200">
            <div className="font-semibold text-slate-800">Trade Theory (TT)</div>
            <div className="text-slate-500 text-[11px] mt-0.5">38 Questions · 76 Marks</div>
            <div className="text-[10px] text-emerald-700 font-semibold mt-1">Core Technical Knowledge</div>
          </div>
          <div className="bg-white p-3.5 rounded-lg border border-slate-200">
            <div className="font-semibold text-slate-800">Workshop Calc & Science</div>
            <div className="text-slate-500 text-[11px] mt-0.5">6 Questions · 12 Marks</div>
            <div className="text-[10px] text-emerald-700 font-semibold mt-1">Units, Math, Heat & Work</div>
          </div>
          <div className="bg-white p-3.5 rounded-lg border border-slate-200">
            <div className="font-semibold text-slate-800">Engineering Drawing (ED)</div>
            <div className="text-slate-500 text-[11px] mt-0.5">6 Questions · 12 Marks</div>
            <div className="text-[10px] text-emerald-700 font-semibold mt-1">Orthographic & Symbols</div>
          </div>
          <div className="bg-white p-3.5 rounded-lg border border-slate-200">
            <div className="font-semibold text-slate-800">Employability Skills (ES)</div>
            <div className="text-slate-500 text-[11px] mt-0.5">25 Questions · 50 Marks</div>
            <div className="text-[10px] text-emerald-700 font-semibold mt-1">IT, English, Safety & Career</div>
          </div>
        </div>

        <div className="mt-4 pt-3 border-t border-slate-200 text-xs text-slate-600 flex flex-wrap items-center justify-between gap-2">
          <div>
            Total: <strong>75 Questions</strong> · <strong>150 Marks</strong> · Time: <strong>120 Minutes</strong>
          </div>
          <div className="text-emerald-700 font-semibold">
            ✓ No Negative Marking · 33% Minimum Passing Marks
          </div>
        </div>
      </div>

      {/* Recent Test History */}
      {results.length > 0 && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Recent Mock Test History
              </h2>
              <p className="text-xs text-slate-500">
                Review your answers, sectional performance, and question explanations.
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-700 border-b border-slate-200">
                <tr>
                  <th className="px-4 py-2.5 font-semibold">Date</th>
                  <th className="px-4 py-2.5 font-semibold">Trade</th>
                  <th className="px-4 py-2.5 font-semibold">Score</th>
                  <th className="px-4 py-2.5 font-semibold">Percentage</th>
                  <th className="px-4 py-2.5 font-semibold">Status</th>
                  <th className="px-4 py-2.5 font-semibold text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {results.slice(0, 5).map(res => (
                  <tr key={res.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="px-4 py-3 text-slate-600 whitespace-nowrap">
                      {new Date(res.date).toLocaleDateString()}
                    </td>
                    <td className="px-4 py-3 font-semibold text-slate-800">
                      {res.tradeName} (Yr {res.year})
                    </td>
                    <td className="px-4 py-3 font-mono font-medium text-slate-900 tabular-nums">
                      {res.score} / {res.maxScore}
                    </td>
                    <td className="px-4 py-3 font-mono font-bold tabular-nums">
                      {res.percentage}%
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                        res.isPassed
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : 'bg-rose-50 text-rose-700 border border-rose-200'
                      }`}>
                        {res.isPassed ? 'PASSED' : 'FAILED'}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <button
                        onClick={() => onReviewPastResult(res)}
                        className="text-xs font-semibold text-slate-900 hover:text-emerald-700 underline cursor-pointer"
                      >
                        Review Solutions
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
