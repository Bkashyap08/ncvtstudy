import React, { useState } from 'react';
import { ExamResult, Question } from '../types';
import { TechnicalDiagram } from './TechnicalDiagram';
import { toggleBookmark, getBookmarkedIds } from '../utils/storage';

interface ExamResultViewProps {
  result: ExamResult;
  questions: Question[];
  onRetake: () => void;
  onGoHome: () => void;
}

export const ExamResultView: React.FC<ExamResultViewProps> = ({
  result,
  questions,
  onRetake,
  onGoHome
}) => {
  const [filterMode, setFilterMode] = useState<'all' | 'incorrect' | 'correct' | 'unattempted'>('all');
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>(getBookmarkedIds());
  const [reviewLang, setReviewLang] = useState<'bilingual' | 'hi' | 'en'>('bilingual');

  const handleToggleBookmark = (qId: string) => {
    toggleBookmark(qId);
    setBookmarkedIds(getBookmarkedIds());
  };

  // Build question review items with corresponding question details
  const reviewItems = questions.map(q => {
    const answerRecord = result.answers.find(a => a.questionId === q.id);
    const userOption = answerRecord?.selectedOption;
    const isCorrect = userOption === q.correctOption;
    const isAttempted = !!userOption;

    return {
      question: q,
      userOption,
      isCorrect,
      isAttempted,
      timeSpent: answerRecord?.timeSpentSeconds || 0
    };
  });

  const filteredItems = reviewItems.filter(item => {
    if (filterMode === 'correct') return item.isCorrect;
    if (filterMode === 'incorrect') return item.isAttempted && !item.isCorrect;
    if (filterMode === 'unattempted') return !item.isAttempted;
    return true;
  });

  const formatSeconds = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}m ${s}s`;
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      {/* Result Card Hero */}
      <div className={`p-8 rounded-xl border text-white shadow-lg mb-8 ${
        result.isPassed
          ? 'bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-950 border-emerald-600/40'
          : 'bg-gradient-to-br from-slate-900 via-slate-800 to-rose-950 border-rose-600/40'
      }`}>
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 pb-6 border-b border-slate-700/60">
          <div>
            <div className="text-xs uppercase tracking-wider text-slate-400 mb-1">
              NCVT CBT Mock Examination Result
            </div>
            <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight">
              {result.tradeName} — Year {result.year}
            </h1>
            <div className="text-xs text-slate-400 mt-1">
              Attempted on {new Date(result.date).toLocaleDateString()} at {new Date(result.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className={`px-4 py-2 rounded-lg font-bold text-sm tracking-wide uppercase ${
              result.isPassed
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/50'
                : 'bg-rose-500/20 text-rose-300 border border-rose-500/50'
            }`}>
              {result.isPassed ? '✓ PASSED (उत्तीर्ण)' : '✗ FAILED (अनुत्तीर्ण)'}
            </div>
          </div>
        </div>

        {/* Big Numbers Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-6">
          <div className="bg-slate-800/60 p-4 rounded-lg border border-slate-700/50">
            <div className="text-xs text-slate-400">Total Marks</div>
            <div className="text-2xl font-bold font-mono mt-1 text-white tabular-nums">
              {result.score} <span className="text-sm font-normal text-slate-400">/ {result.maxScore}</span>
            </div>
          </div>

          <div className="bg-slate-800/60 p-4 rounded-lg border border-slate-700/50">
            <div className="text-xs text-slate-400">Percentage</div>
            <div className={`text-2xl font-bold font-mono mt-1 tabular-nums ${
              result.isPassed ? 'text-emerald-400' : 'text-rose-400'
            }`}>
              {result.percentage}%
            </div>
          </div>

          <div className="bg-slate-800/60 p-4 rounded-lg border border-slate-700/50">
            <div className="text-xs text-slate-400">Accuracy</div>
            <div className="text-2xl font-bold font-mono mt-1 text-amber-300 tabular-nums">
              {result.attemptedQuestions > 0
                ? Math.round((result.correctAnswers / result.attemptedQuestions) * 100)
                : 0}%
            </div>
          </div>

          <div className="bg-slate-800/60 p-4 rounded-lg border border-slate-700/50">
            <div className="text-xs text-slate-400">Time Taken</div>
            <div className="text-2xl font-bold font-mono mt-1 text-slate-200 tabular-nums">
              {formatSeconds(result.timeTakenSeconds)}
            </div>
          </div>
        </div>

        {/* Sectional Breakdown */}
        {result.categoryBreakdown.length > 0 && (
          <div className="mt-6 pt-6 border-t border-slate-700/60">
            <div className="text-xs text-slate-400 mb-3 font-medium uppercase tracking-wider">
              Sectional Performance
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
              {result.categoryBreakdown.map(sec => {
                const label =
                  sec.category === 'trade_theory'
                    ? 'Trade Theory'
                    : sec.category === 'workshop_calc'
                    ? 'WCS'
                    : sec.category === 'engineering_drawing'
                    ? 'Eng. Drawing'
                    : 'Employability';
                return (
                  <div key={sec.category} className="bg-slate-800/40 p-3 rounded border border-slate-700/40 text-xs">
                    <div className="font-semibold text-slate-300">{label}</div>
                    <div className="flex items-center justify-between mt-1 text-slate-400">
                      <span>Score: {sec.correct * 2}/{sec.total * 2}</span>
                      <span className="font-mono text-white font-bold">{Math.round(sec.percentage)}%</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Actions bar */}
        <div className="mt-8 flex flex-wrap items-center gap-3">
          <button
            onClick={onRetake}
            className="px-5 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs shadow transition-colors cursor-pointer"
          >
            Retake Exam
          </button>
          <button
            onClick={onGoHome}
            className="px-5 py-2.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-white font-semibold text-xs transition-colors cursor-pointer"
          >
            Go to Dashboard
          </button>
        </div>
      </div>

      {/* Solutions & Analysis Header */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs mb-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              Detailed Question Solutions & Key
            </h2>
            <p className="text-xs text-slate-500">
              Review correct answers, explanations, and NIMI textbook references.
            </p>
          </div>

          <div className="flex items-center gap-3">
            {/* Language toggle for review */}
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-md text-xs">
              <button
                onClick={() => setReviewLang('bilingual')}
                className={`px-2.5 py-1 rounded transition-colors ${reviewLang === 'bilingual' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600'}`}
              >
                Dual
              </button>
              <button
                onClick={() => setReviewLang('hi')}
                className={`px-2.5 py-1 rounded transition-colors ${reviewLang === 'hi' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600'}`}
              >
                हिन्दी
              </button>
              <button
                onClick={() => setReviewLang('en')}
                className={`px-2.5 py-1 rounded transition-colors ${reviewLang === 'en' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600'}`}
              >
                English
              </button>
            </div>
          </div>
        </div>

        {/* Filter buttons */}
        <div className="flex items-center gap-2 mt-4 flex-wrap">
          <button
            onClick={() => setFilterMode('all')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium cursor-pointer transition-colors ${
              filterMode === 'all'
                ? 'bg-slate-900 text-white'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            All Questions ({reviewItems.length})
          </button>
          <button
            onClick={() => setFilterMode('incorrect')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium cursor-pointer transition-colors ${
              filterMode === 'incorrect'
                ? 'bg-rose-600 text-white'
                : 'bg-rose-50 text-rose-700 hover:bg-rose-100'
            }`}
          >
            Incorrect ({result.incorrectAnswers})
          </button>
          <button
            onClick={() => setFilterMode('correct')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium cursor-pointer transition-colors ${
              filterMode === 'correct'
                ? 'bg-emerald-600 text-white'
                : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
            }`}
          >
            Correct ({result.correctAnswers})
          </button>
          <button
            onClick={() => setFilterMode('unattempted')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium cursor-pointer transition-colors ${
              filterMode === 'unattempted'
                ? 'bg-slate-700 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Unattempted ({result.totalQuestions - result.attemptedQuestions})
          </button>
        </div>
      </div>

      {/* Question Cards List */}
      <div className="space-y-6">
        {filteredItems.map((item, idx) => {
          const { question: q, userOption, isCorrect, isAttempted } = item;
          const isBookmarked = bookmarkedIds.includes(q.id);

          return (
            <div
              key={q.id}
              className={`p-6 rounded-xl border bg-white shadow-xs transition-all ${
                isAttempted
                  ? isCorrect
                    ? 'border-emerald-200'
                    : 'border-rose-200'
                  : 'border-slate-200'
              }`}
            >
              {/* Question Header */}
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <span className="font-mono font-bold text-xs bg-slate-100 text-slate-800 px-2 py-0.5 rounded">
                    Q{idx + 1}
                  </span>
                  <span className="text-xs text-slate-500">
                    {q.module}
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  {/* Status Indicator */}
                  {isAttempted ? (
                    isCorrect ? (
                      <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded border border-emerald-200">
                        ✓ Correct (+2.0)
                      </span>
                    ) : (
                      <span className="text-xs font-bold text-rose-700 bg-rose-50 px-2.5 py-0.5 rounded border border-rose-200">
                        ✗ Incorrect (0.0)
                      </span>
                    )
                  ) : (
                    <span className="text-xs text-slate-500 bg-slate-100 px-2.5 py-0.5 rounded">
                      Unattempted
                    </span>
                  )}

                  {/* Bookmark Button */}
                  <button
                    onClick={() => handleToggleBookmark(q.id)}
                    className={`p-1.5 rounded transition-colors cursor-pointer text-xs flex items-center gap-1 ${
                      isBookmarked
                        ? 'text-amber-600 bg-amber-50 hover:bg-amber-100'
                        : 'text-slate-400 hover:text-slate-700 hover:bg-slate-100'
                    }`}
                    title={isBookmarked ? 'Remove from Revision Bookmarks' : 'Save to Revision Bookmarks'}
                  >
                    ★ {isBookmarked ? 'Saved' : 'Save'}
                  </button>
                </div>
              </div>

              {/* Question Statement */}
              {(reviewLang === 'en' || reviewLang === 'bilingual') && (
                <div className="font-medium text-slate-900 text-base mb-2">
                  {q.question.en}
                </div>
              )}
              {(reviewLang === 'hi' || reviewLang === 'bilingual') && (
                <div className="font-normal text-slate-800 text-base mb-4 font-devanagari">
                  {q.question.hi}
                </div>
              )}

              {/* Diagram if any */}
              {q.diagramType && (
                <TechnicalDiagram
                  type={q.diagramType}
                  caption={q.diagramData?.caption}
                  language={reviewLang}
                />
              )}

              {/* Options Breakdown */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 my-4">
                {q.options.map(opt => {
                  const isOfficialCorrect = opt.id === q.correctOption;
                  const isUserSelected = opt.id === userOption;

                  let cardStyle = 'border-slate-200 bg-slate-50/50';
                  if (isOfficialCorrect) {
                    cardStyle = 'border-emerald-500 bg-emerald-50/60 text-emerald-950 font-semibold ring-1 ring-emerald-500';
                  } else if (isUserSelected && !isOfficialCorrect) {
                    cardStyle = 'border-rose-400 bg-rose-50 text-rose-950 ring-1 ring-rose-400';
                  }

                  return (
                    <div
                      key={opt.id}
                      className={`p-3 rounded-lg border text-xs flex items-start gap-2.5 ${cardStyle}`}
                    >
                      <span className={`w-5 h-5 rounded-full flex items-center justify-center font-bold shrink-0 text-[11px] ${
                        isOfficialCorrect
                          ? 'bg-emerald-600 text-white'
                          : isUserSelected
                          ? 'bg-rose-600 text-white'
                          : 'bg-slate-200 text-slate-700'
                      }`}>
                        {opt.id}
                      </span>
                      <div className="flex-1">
                        <div>{reviewLang === 'hi' ? opt.text.hi : opt.text.en}</div>
                        {reviewLang === 'bilingual' && (
                          <div className="text-slate-500 font-devanagari mt-0.5">{opt.text.hi}</div>
                        )}
                      </div>
                      {isOfficialCorrect && (
                        <span className="text-[10px] uppercase font-bold text-emerald-700 bg-emerald-100/80 px-1.5 py-0.5 rounded shrink-0">
                          Answer
                        </span>
                      )}
                      {isUserSelected && !isOfficialCorrect && (
                        <span className="text-[10px] uppercase font-bold text-rose-700 bg-rose-100/80 px-1.5 py-0.5 rounded shrink-0">
                          Your choice
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* NIMI Solution & Explanation Box */}
              <div className="p-4 rounded-lg bg-amber-50/80 border border-amber-200/80 text-xs">
                <div className="font-bold text-amber-900 mb-1 flex items-center gap-1.5">
                  <span>💡 Solution & Concept Explanation:</span>
                  {q.source && <span className="text-[11px] font-normal text-amber-700">({q.source})</span>}
                </div>
                {(reviewLang === 'en' || reviewLang === 'bilingual') && (
                  <p className="text-amber-950 leading-relaxed mb-1">{q.explanation.en}</p>
                )}
                {(reviewLang === 'hi' || reviewLang === 'bilingual') && (
                  <p className="text-amber-900 leading-relaxed font-devanagari">{q.explanation.hi}</p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
