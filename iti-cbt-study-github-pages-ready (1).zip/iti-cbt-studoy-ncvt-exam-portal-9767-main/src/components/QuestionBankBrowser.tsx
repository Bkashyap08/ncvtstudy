import React, { useState, useMemo } from 'react';
import { QUESTIONS_BANK } from '../data/questions';
import { TRADES, SUBJECT_CATEGORIES } from '../data/trades';
import { TechnicalDiagram } from './TechnicalDiagram';
import { toggleBookmark, getBookmarkedIds } from '../utils/storage';

export const QuestionBankBrowser: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedTrade, setSelectedTrade] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [onlyBookmarked, setOnlyBookmarked] = useState<boolean>(false);
  const [revealedIds, setRevealedIds] = useState<{ [qId: string]: boolean }>({});
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>(getBookmarkedIds());
  const [language, setLanguage] = useState<'bilingual' | 'hi' | 'en'>('bilingual');

  const handleToggleReveal = (qId: string) => {
    setRevealedIds(prev => ({
      ...prev,
      [qId]: !prev[qId]
    }));
  };

  const handleToggleBookmark = (qId: string) => {
    toggleBookmark(qId);
    setBookmarkedIds(getBookmarkedIds());
  };

  const filteredQuestions = useMemo(() => {
    return QUESTIONS_BANK.filter(q => {
      // Bookmark filter
      if (onlyBookmarked && !bookmarkedIds.includes(q.id)) {
        return false;
      }

      // Trade filter
      if (selectedTrade !== 'all') {
        const matchesTrade = q.tradeId === selectedTrade || 
          (selectedTrade === 'engineering_common' && q.tradeId === 'common_engineering') ||
          (selectedTrade === 'all_common' && q.tradeId === 'common_all');
        if (!matchesTrade) return false;
      }

      // Category filter
      if (selectedCategory !== 'all' && q.subjectCategory !== selectedCategory) {
        return false;
      }

      // Search term
      if (searchTerm.trim()) {
        const query = searchTerm.toLowerCase();
        const matchesEn = q.question.en.toLowerCase().includes(query);
        const matchesHi = q.question.hi.toLowerCase().includes(query);
        const matchesMod = q.module.toLowerCase().includes(query);
        const matchesOptions = q.options.some(
          o => o.text.en.toLowerCase().includes(query) || o.text.hi.toLowerCase().includes(query)
        );
        if (!matchesEn && !matchesHi && !matchesMod && !matchesOptions) {
          return false;
        }
      }

      return true;
    });
  }, [searchTerm, selectedTrade, selectedCategory, onlyBookmarked, bookmarkedIds]);

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      {/* Title */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            NIMI & Bharat Skills Question Bank
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Searchable repository of official NCVT CBT question banks with bilingual support.
          </p>
        </div>

        {/* Language switch */}
        <div className="flex items-center gap-1 bg-white border border-slate-200 p-1 rounded-lg text-xs shadow-xs">
          <button
            onClick={() => setLanguage('bilingual')}
            className={`px-3 py-1 rounded transition-colors ${
              language === 'bilingual' ? 'bg-slate-900 text-white font-semibold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Dual (EN+HI)
          </button>
          <button
            onClick={() => setLanguage('hi')}
            className={`px-3 py-1 rounded transition-colors ${
              language === 'hi' ? 'bg-slate-900 text-white font-semibold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            हिन्दी
          </button>
          <button
            onClick={() => setLanguage('en')}
            className={`px-3 py-1 rounded transition-colors ${
              language === 'en' ? 'bg-slate-900 text-white font-semibold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            English
          </button>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs mb-6 space-y-4">
        {/* Search Input */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Search Question or Keywords (English or हिन्दी)
          </label>
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="e.g. micrometer, transformer, flame, ohms law, वर्नियर..."
            className="w-full text-xs p-2.5 rounded-lg border border-slate-300 focus:ring-1 focus:ring-slate-900 focus:outline-none"
          />
        </div>

        {/* Filter Row */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Filter Trade</label>
            <select
              value={selectedTrade}
              onChange={e => setSelectedTrade(e.target.value)}
              className="w-full text-xs p-2 rounded-lg border border-slate-300 bg-white focus:outline-none"
            >
              <option value="all">All Trades & Common</option>
              {TRADES.map(t => (
                <option key={t.id} value={t.id}>
                  {t.name.en} ({t.code})
                </option>
              ))}
              <option value="engineering_common">Engineering Common (WCS / ED)</option>
              <option value="all_common">Employability Skills (All Trades)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Filter Subject Category</label>
            <select
              value={selectedCategory}
              onChange={e => setSelectedCategory(e.target.value)}
              className="w-full text-xs p-2 rounded-lg border border-slate-300 bg-white focus:outline-none"
            >
              <option value="all">All Subjects</option>
              {SUBJECT_CATEGORIES.map(sub => (
                <option key={sub.id} value={sub.id}>
                  {sub.name.en}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-end pb-1">
            <button
              onClick={() => setOnlyBookmarked(prev => !prev)}
              className={`w-full py-2 px-3 rounded-lg text-xs font-semibold border transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                onlyBookmarked
                  ? 'bg-amber-50 border-amber-300 text-amber-800 ring-1 ring-amber-400'
                  : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
              }`}
            >
              ★ {onlyBookmarked ? 'Showing Bookmarked Only' : `Show Bookmarked (${bookmarkedIds.length})`}
            </button>
          </div>
        </div>
      </div>

      {/* Result Count Status */}
      <div className="flex items-center justify-between text-xs text-slate-500 mb-4 px-1">
        <span>Found <strong>{filteredQuestions.length}</strong> matching questions</span>
        <button
          onClick={() => {
            const allTrue: { [qId: string]: boolean } = {};
            filteredQuestions.forEach(q => (allTrue[q.id] = true));
            setRevealedIds(allTrue);
          }}
          className="text-xs text-slate-700 hover:underline cursor-pointer"
        >
          Reveal all answers
        </button>
      </div>

      {/* Question List */}
      <div className="space-y-4">
        {filteredQuestions.map((q, idx) => {
          const isRevealed = !!revealedIds[q.id];
          const isBookmarked = bookmarkedIds.includes(q.id);

          return (
            <div key={q.id} className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
              {/* Question metadata row */}
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs font-bold bg-slate-100 text-slate-700 px-2 py-0.5 rounded">
                    #{idx + 1}
                  </span>
                  <span className="text-xs text-slate-500 font-medium">
                    {q.module}
                  </span>
                  <span className="text-xs text-slate-400">·</span>
                  <span className="text-[11px] text-slate-400 uppercase font-mono">
                    {q.tradeId}
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    onClick={() => handleToggleBookmark(q.id)}
                    className={`p-1.5 rounded text-xs transition-colors cursor-pointer flex items-center gap-1 ${
                      isBookmarked
                        ? 'text-amber-600 bg-amber-50 font-bold'
                        : 'text-slate-400 hover:text-slate-700'
                    }`}
                  >
                    ★ {isBookmarked ? 'Saved' : 'Save'}
                  </button>
                </div>
              </div>

              {/* Question text */}
              {(language === 'en' || language === 'bilingual') && (
                <div className="font-semibold text-slate-900 text-base mb-1.5 leading-relaxed">
                  {q.question.en}
                </div>
              )}
              {(language === 'hi' || language === 'bilingual') && (
                <div className="font-normal text-slate-800 text-base mb-4 font-devanagari leading-relaxed">
                  {q.question.hi}
                </div>
              )}

              {/* Diagram */}
              {q.diagramType && (
                <TechnicalDiagram
                  type={q.diagramType}
                  caption={q.diagramData?.caption}
                  language={language}
                />
              )}

              {/* Options grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 my-4">
                {q.options.map(opt => {
                  const isCorrect = opt.id === q.correctOption;
                  return (
                    <div
                      key={opt.id}
                      className={`p-3 rounded-lg border text-xs flex items-start gap-2.5 transition-colors ${
                        isRevealed && isCorrect
                          ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-semibold ring-1 ring-emerald-500'
                          : 'bg-slate-50/70 border-slate-200 text-slate-800'
                      }`}
                    >
                      <span className={`w-5 h-5 rounded-full flex items-center justify-center font-bold text-[11px] shrink-0 ${
                        isRevealed && isCorrect ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-700'
                      }`}>
                        {opt.id}
                      </span>
                      <div className="flex-1">
                        <div>{language === 'hi' ? opt.text.hi : opt.text.en}</div>
                        {language === 'bilingual' && (
                          <div className="text-slate-500 font-devanagari mt-0.5 text-[11px]">
                            {opt.text.hi}
                          </div>
                        )}
                      </div>
                      {isRevealed && isCorrect && (
                        <span className="text-[10px] uppercase font-bold text-emerald-700 bg-emerald-100 px-1.5 py-0.5 rounded shrink-0">
                          Correct
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Reveal explanation button */}
              <div className="pt-2 flex items-center justify-between border-t border-slate-100">
                <button
                  onClick={() => handleToggleReveal(q.id)}
                  className="text-xs font-semibold text-slate-700 hover:text-slate-900 flex items-center gap-1 cursor-pointer"
                >
                  {isRevealed ? '▲ Hide Explanation' : '▼ Show Correct Answer & Solution'}
                </button>

                {q.source && (
                  <span className="text-[11px] text-slate-400 font-mono">
                    {q.source}
                  </span>
                )}
              </div>

              {/* Unfolded Solution */}
              {isRevealed && (
                <div className="mt-4 p-4 rounded-lg bg-amber-50/90 border border-amber-200 text-xs text-amber-950 animate-in fade-in duration-150">
                  <div className="font-bold text-amber-900 mb-1">
                    Correct Option: {q.correctOption}
                  </div>
                  {(language === 'en' || language === 'bilingual') && (
                    <p className="leading-relaxed mb-1.5">{q.explanation.en}</p>
                  )}
                  {(language === 'hi' || language === 'bilingual') && (
                    <p className="leading-relaxed font-devanagari text-amber-900">{q.explanation.hi}</p>
                  )}
                </div>
              )}
            </div>
          );
        })}

        {filteredQuestions.length === 0 && (
          <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
            <div className="text-slate-600 font-semibold mb-1">No questions found</div>
            <p className="text-xs text-slate-400">
              Try adjusting your search keywords or clearing active filters.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
