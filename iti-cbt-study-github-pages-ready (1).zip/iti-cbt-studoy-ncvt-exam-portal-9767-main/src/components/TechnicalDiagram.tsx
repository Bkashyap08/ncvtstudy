import React from 'react';
import { Question } from '../types';

interface TechnicalDiagramProps {
  type: Question['diagramType'];
  caption?: { en: string; hi: string };
  language: 'en' | 'hi' | 'bilingual';
}

export const TechnicalDiagram: React.FC<TechnicalDiagramProps> = ({ type, caption, language }) => {
  if (!type) return null;

  return (
    <div className="my-4 p-4 bg-slate-900 text-white rounded-lg border border-slate-800">
      <div className="text-xs text-amber-400 font-mono tracking-wider mb-2 uppercase flex items-center justify-between">
        <span>Technical Diagram / तकनीकी चित्र</span>
        <span className="text-slate-400 text-[11px]">NIMI / NCVT Standard</span>
      </div>

      <div className="flex justify-center items-center py-2 overflow-x-auto">
        {type === 'vernier' && (
          <svg viewBox="0 0 500 140" className="w-full max-w-lg h-auto select-none" xmlns="http://www.w3.org/2000/svg">
            {/* Main beam */}
            <rect x="20" y="20" width="460" height="50" fill="#1e293b" stroke="#64748b" strokeWidth="2" rx="4" />
            <text x="30" y="45" fill="#94a3b8" fontSize="12" fontFamily="monospace">MAIN SCALE (mm)</text>
            {/* Main scale graduations */}
            {Array.from({ length: 41 }).map((_, i) => (
              <g key={`ms-${i}`}>
                <line
                  x1={50 + i * 10}
                  y1={20}
                  x2={50 + i * 10}
                  y2={i % 10 === 0 ? 55 : i % 5 === 0 ? 45 : 35}
                  stroke="#cbd5e1"
                  strokeWidth={i % 10 === 0 ? 2 : 1}
                />
                {i % 10 === 0 && (
                  <text x={46 + i * 10} y="66" fill="#cbd5e1" fontSize="11" fontFamily="monospace">
                    {i}
                  </text>
                )}
              </g>
            ))}

            {/* Sliding Vernier Plate */}
            <rect x="120" y="60" width="220" height="60" fill="#0f172a" stroke="#38bdf8" strokeWidth="2" rx="4" />
            <text x="130" y="105" fill="#38bdf8" fontSize="11" fontFamily="monospace">VERNIER SCALE (LC = 0.02 mm)</text>
            {/* Vernier divisions 0 to 50 */}
            {Array.from({ length: 21 }).map((_, j) => (
              <g key={`vs-${j}`}>
                <line
                  x1={130 + j * 9.8}
                  y1={60}
                  x2={130 + j * 9.8}
                  y2={j % 5 === 0 ? 82 : 72}
                  stroke={j === 12 ? '#f59e0b' : '#38bdf8'}
                  strokeWidth={j === 12 ? 2.5 : 1}
                />
                {j % 5 === 0 && (
                  <text x={126 + j * 9.8} y="94" fill="#38bdf8" fontSize="10" fontFamily="monospace">
                    {j / 2}
                  </text>
                )}
              </g>
            ))}
            {/* Alignment indicator */}
            <line x1="247.6" y1="52" x2="247.6" y2="84" stroke="#f59e0b" strokeWidth="2" strokeDasharray="3,2" />
            <text x="255" y="78" fill="#f59e0b" fontSize="11" fontWeight="bold">Coinciding Line</text>
          </svg>
        )}

        {type === 'micrometer' && (
          <svg viewBox="0 0 460 140" className="w-full max-w-lg h-auto select-none" xmlns="http://www.w3.org/2000/svg">
            {/* Sleeve Barrel */}
            <rect x="40" y="30" width="200" height="80" fill="#1e293b" stroke="#64748b" strokeWidth="2" rx="4" />
            {/* Datum line */}
            <line x1="40" y1="70" x2="240" y2="70" stroke="#f8fafc" strokeWidth="2" />
            {/* Sleeve graduations */}
            {Array.from({ length: 16 }).map((_, i) => (
              <g key={`sl-${i}`}>
                {/* Upper 1mm marks */}
                <line x1={50 + i * 10} y1={50} x2={50 + i * 10} y2={70} stroke="#cbd5e1" strokeWidth={i % 5 === 0 ? 2 : 1} />
                {i % 5 === 0 && (
                  <text x={46 + i * 10} y="44" fill="#cbd5e1" fontSize="11" fontFamily="monospace">{i}</text>
                )}
                {/* Lower 0.5mm marks */}
                {i < 15 && (
                  <line x1={55 + i * 10} y1={70} x2={55 + i * 10} y2={85} stroke="#94a3b8" strokeWidth="1" />
                )}
              </g>
            ))}

            {/* Thimble Bevel */}
            <path d="M 240,20 L 260,35 L 360,35 L 360,105 L 260,105 L 240,120 Z" fill="#0f172a" stroke="#38bdf8" strokeWidth="2" />
            {/* Thimble scale divisions */}
            {[-10, -5, 0, 5, 10, 15, 20].map((val, idx) => (
              <g key={`th-${idx}`}>
                <line x1="244" y1={70 - val * 2.2} x2="260" y2={70 - val * 2.2} stroke="#38bdf8" strokeWidth={val % 5 === 0 ? 2 : 1} />
                <text x="264" y={74 - val * 2.2} fill="#38bdf8" fontSize="10" fontFamily="monospace">
                  {val < 0 ? 50 + val : val}
                </text>
              </g>
            ))}
            <text x="280" y="125" fill="#94a3b8" fontSize="10" fontFamily="monospace">THIMBLE (50 DIV)</text>
          </svg>
        )}

        {type === 'circuit' && (
          <svg viewBox="0 0 400 140" className="w-full max-w-md h-auto" xmlns="http://www.w3.org/2000/svg">
            {/* Left Magnetic Pole N */}
            <rect x="40" y="30" width="50" height="80" fill="#dc2626" rx="4" />
            <text x="58" y="76" fill="#fff" fontSize="20" fontWeight="bold">N</text>
            {/* Right Magnetic Pole S */}
            <rect x="310" y="30" width="50" height="80" fill="#2563eb" rx="4" />
            <text x="328" y="76" fill="#fff" fontSize="20" fontWeight="bold">S</text>
            {/* Magnetic flux lines */}
            <path d="M 95,50 L 305,50" stroke="#94a3b8" strokeWidth="2" strokeDasharray="4,4" markerEnd="url(#arrow)" />
            <path d="M 95,70 L 305,70" stroke="#94a3b8" strokeWidth="2" strokeDasharray="4,4" />
            <path d="M 95,90 L 305,90" stroke="#94a3b8" strokeWidth="2" strokeDasharray="4,4" />
            {/* Conductor loop */}
            <circle cx="200" cy="70" r="18" fill="#1e293b" stroke="#f59e0b" strokeWidth="3" />
            <circle cx="200" cy="70" r="4" fill="#f59e0b" />
            <text x="180" y="112" fill="#f59e0b" fontSize="11" fontWeight="bold">Current (• Outward)</text>
            {/* Upward Force Arrow */}
            <line x1="200" y1="46" x2="200" y2="16" stroke="#10b981" strokeWidth="3" />
            <polygon points="200,8 194,18 206,18" fill="#10b981" />
            <text x="210" y="24" fill="#10b981" fontSize="12" fontWeight="bold">Force / Motion</text>
          </svg>
        )}

        {type === 'transformer' && (
          <svg viewBox="0 0 380 140" className="w-full max-w-md h-auto" xmlns="http://www.w3.org/2000/svg">
            {/* Core */}
            <rect x="90" y="20" width="200" height="100" fill="none" stroke="#64748b" strokeWidth="16" rx="4" />
            {/* Primary Windings */}
            <g stroke="#f59e0b" strokeWidth="4" strokeLinecap="round">
              <path d="M 60,35 Q 90,30 90,45" fill="none" />
              <path d="M 60,55 Q 90,50 90,65" fill="none" />
              <path d="M 60,75 Q 90,70 90,85" fill="none" />
              <path d="M 60,95 Q 90,90 90,105" fill="none" />
            </g>
            <text x="20" y="75" fill="#f59e0b" fontSize="12" fontWeight="bold">Primary (Np)</text>

            {/* Secondary Windings */}
            <g stroke="#38bdf8" strokeWidth="4" strokeLinecap="round">
              <path d="M 290,45 Q 290,30 320,35" fill="none" />
              <path d="M 290,65 Q 290,50 320,55" fill="none" />
              <path d="M 290,85 Q 290,70 320,75" fill="none" />
              <path d="M 290,105 Q 290,90 320,95" fill="none" />
            </g>
            <text x="325" y="75" fill="#38bdf8" fontSize="12" fontWeight="bold">Secondary (Ns)</text>
            <text x="145" y="75" fill="#94a3b8" fontSize="11" fontFamily="monospace">Core Flux (Φ)</text>
          </svg>
        )}

        {type === 'logic_gate' && (
          <svg viewBox="0 0 360 130" className="w-full max-w-sm h-auto" xmlns="http://www.w3.org/2000/svg">
            {/* Inputs A & B */}
            <line x1="50" y1="45" x2="130" y2="45" stroke="#cbd5e1" strokeWidth="3" />
            <text x="30" y="50" fill="#cbd5e1" fontSize="14" fontWeight="bold">A</text>
            <line x1="50" y1="85" x2="130" y2="85" stroke="#cbd5e1" strokeWidth="3" />
            <text x="30" y="90" fill="#cbd5e1" fontSize="14" fontWeight="bold">B</text>

            {/* Gate Body: NOR */}
            <path d="M 120,30 Q 150,65 120,100 Q 180,100 220,65 Q 180,30 120,30 Z" fill="#1e293b" stroke="#38bdf8" strokeWidth="3" />
            {/* Inversion Bubble */}
            <circle cx="228" cy="65" r="7" fill="#0f172a" stroke="#38bdf8" strokeWidth="2.5" />
            {/* Output */}
            <line x1="235" y1="65" x2="300" y2="65" stroke="#cbd5e1" strokeWidth="3" />
            <text x="308" y="70" fill="#10b981" fontSize="14" fontWeight="bold">Y = (A+B)'</text>
          </svg>
        )}

        {type === 'safety_sign' && (
          <svg viewBox="0 0 340 120" className="w-full max-w-sm h-auto" xmlns="http://www.w3.org/2000/svg">
            {/* Caution Triangle */}
            <polygon points="80,15 25,105 135,105" fill="#eab308" stroke="#ca8a04" strokeWidth="3" />
            <polygon points="80,25 35,98 125,98" fill="#ca8a04" />
            <polygon points="80,30 40,94 120,94" fill="#eab308" />
            <text x="75" y="80" fill="#000" fontSize="38" fontWeight="900" fontFamily="sans-serif">!</text>

            <rect x="170" y="25" width="140" height="70" fill="#dc2626" rx="6" />
            <text x="185" y="52" fill="#fff" fontSize="13" fontWeight="bold">CLASS B FIRE</text>
            <text x="185" y="72" fill="#fef08a" fontSize="11">Use Foam/Dry Powder</text>
            <text x="185" y="86" fill="#fca5a5" fontSize="10">DO NOT USE WATER</text>
          </svg>
        )}

        {type === 'drawing_projection' && (
          <svg viewBox="0 0 380 130" className="w-full max-w-md h-auto" xmlns="http://www.w3.org/2000/svg">
            {/* 1st Angle Projection Symbol */}
            {/* Frustum */}
            <polygon points="60,40 120,20 120,110 60,90" fill="#1e293b" stroke="#cbd5e1" strokeWidth="2" />
            <line x1="40" y1="65" x2="240" y2="65" stroke="#f59e0b" strokeWidth="1" strokeDasharray="6,3,1,3" />
            {/* Concentric circles */}
            <circle cx="190" cy="65" r="45" fill="none" stroke="#cbd5e1" strokeWidth="2" />
            <circle cx="190" cy="65" r="25" fill="none" stroke="#cbd5e1" strokeWidth="2" />
            <text x="250" y="60" fill="#cbd5e1" fontSize="11" fontWeight="bold">1st Angle</text>
            <text x="250" y="76" fill="#94a3b8" fontSize="10">Symbol (ISO/BIS)</text>
          </svg>
        )}
      </div>

      {caption && (
        <div className="text-center text-xs text-slate-300 mt-2 font-medium">
          {language === 'hi' ? caption.hi : caption.en}
        </div>
      )}
    </div>
  );
};
