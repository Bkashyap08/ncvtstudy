import React, { useState } from 'react';
import { CHEATSHEETS } from '../data/cheatsheets';

export const CheatsheetsView: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<'all' | 'electrician' | 'fitter' | 'wcs' | 'welder'>('all');
  const [language, setLanguage] = useState<'en' | 'hi'>('en');

  // Interactive Resistor Calculator State
  const [band1, setBand1] = useState<number>(1); // Brown
  const [band2, setBand2] = useState<number>(0); // Black
  const [multiplierPower, setMultiplierPower] = useState<number>(2); // Red (x100)
  const [toleranceVal, setToleranceVal] = useState<number>(5); // Gold (5%)

  // Resistor color map
  const colorMap = [
    { name: 'Black (0)', value: 0, bg: '#000000', text: '#ffffff' },
    { name: 'Brown (1)', value: 1, bg: '#8B4513', text: '#ffffff' },
    { name: 'Red (2)', value: 2, bg: '#DC2626', text: '#ffffff' },
    { name: 'Orange (3)', value: 3, bg: '#EA580C', text: '#ffffff' },
    { name: 'Yellow (4)', value: 4, bg: '#CA8A04', text: '#ffffff' },
    { name: 'Green (5)', value: 5, bg: '#16A34A', text: '#ffffff' },
    { name: 'Blue (6)', value: 6, bg: '#2563EB', text: '#ffffff' },
    { name: 'Violet (7)', value: 7, bg: '#9333EA', text: '#ffffff' },
    { name: 'Grey (8)', value: 8, bg: '#6B7280', text: '#ffffff' },
    { name: 'White (9)', value: 9, bg: '#F3F4F6', text: '#111827' }
  ];

  // Calculated resistance
  const rawResistance = (band1 * 10 + band2) * Math.pow(10, multiplierPower);
  const formattedResistance =
    rawResistance >= 1000000
      ? `${(rawResistance / 1000000).toFixed(2)} MΩ`
      : rawResistance >= 1000
      ? `${(rawResistance / 1000).toFixed(2)} kΩ`
      : `${rawResistance} Ω`;

  const filteredCheatsheets = CHEATSHEETS.filter(item => {
    if (activeCategory !== 'all' && item.category !== activeCategory) return false;
    return true;
  });

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            ITI Formulas & Workshop Reference Tools
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Quick-access formula cheat sheets, conversion charts, and interactive calculators for CBT exams.
          </p>
        </div>

        <div className="flex items-center gap-1 bg-white border border-slate-200 p-1 rounded-lg text-xs shadow-xs">
          <button
            onClick={() => setLanguage('en')}
            className={`px-3 py-1 rounded transition-colors ${
              language === 'en' ? 'bg-slate-900 text-white font-semibold' : 'text-slate-600'
            }`}
          >
            English
          </button>
          <button
            onClick={() => setLanguage('hi')}
            className={`px-3 py-1 rounded transition-colors ${
              language === 'hi' ? 'bg-slate-900 text-white font-semibold' : 'text-slate-600'
            }`}
          >
            हिन्दी
          </button>
        </div>
      </div>

      {/* Category selector */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 mb-6">
        {[
          { id: 'all', label: 'All Topics' },
          { id: 'electrician', label: 'Electrician' },
          { id: 'fitter', label: 'Fitter & Machining' },
          { id: 'wcs', label: 'Workshop Calc (WCS)' },
          { id: 'welder', label: 'Welding & Fab' }
        ].map(cat => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id as any)}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap cursor-pointer transition-colors ${
              activeCategory === cat.id
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Interactive Tool Spotlight: Resistor Color Code Calculator */}
      {(activeCategory === 'all' || activeCategory === 'electrician') && (
        <div className="bg-slate-900 text-white rounded-xl p-6 md:p-8 mb-8 shadow-lg border border-slate-800">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
            <div>
              <span className="text-xs uppercase font-mono text-amber-400 font-semibold tracking-wider">
                Interactive Workshop Tool
              </span>
              <h2 className="text-xl font-bold mt-0.5">
                4-Band Resistor Value Calculator
              </h2>
            </div>
            <div className="text-right">
              <div className="text-xs text-slate-400">Calculated Value</div>
              <div className="text-2xl md:text-3xl font-mono font-extrabold text-emerald-400 tabular-nums">
                {formattedResistance} <span className="text-sm font-normal text-slate-300">± {toleranceVal}%</span>
              </div>
            </div>
          </div>

          {/* SVG Visual Resistor */}
          <div className="py-6 flex justify-center">
            <svg viewBox="0 0 460 110" className="w-full max-w-md h-auto">
              {/* Resistor Lead Wire Left */}
              <line x1="20" y1="55" x2="110" y2="55" stroke="#94a3b8" strokeWidth="6" strokeLinecap="round" />
              {/* Resistor Lead Wire Right */}
              <line x1="350" y1="55" x2="440" y2="55" stroke="#94a3b8" strokeWidth="6" strokeLinecap="round" />
              {/* Resistor Ceramic Body */}
              <rect x="110" y="25" width="240" height="60" rx="20" fill="#e2d9c8" stroke="#b8a994" strokeWidth="3" />
              {/* Central bulb taper */}
              <rect x="150" y="30" width="160" height="50" rx="8" fill="#e2d9c8" />

              {/* Band 1 */}
              <rect x="145" y="25" width="16" height="60" fill={colorMap[band1]?.bg} />
              {/* Band 2 */}
              <rect x="185" y="25" width="16" height="60" fill={colorMap[band2]?.bg} />
              {/* Band 3 Multiplier */}
              <rect x="225" y="25" width="16" height="60" fill={colorMap[multiplierPower]?.bg} />
              {/* Band 4 Tolerance */}
              <rect x="295" y="25" width="16" height="60" fill={toleranceVal === 5 ? '#eab308' : '#cbd5e1'} />
            </svg>
          </div>

          {/* Color Selector Controls */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">1st Digit (Band 1)</label>
              <select
                value={band1}
                onChange={e => setBand1(parseInt(e.target.value, 10))}
                className="w-full p-2 rounded bg-slate-800 border border-slate-700 text-white focus:outline-none"
              >
                {colorMap.slice(1).map(c => (
                  <option key={`b1-${c.value}`} value={c.value}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">2nd Digit (Band 2)</label>
              <select
                value={band2}
                onChange={e => setBand2(parseInt(e.target.value, 10))}
                className="w-full p-2 rounded bg-slate-800 border border-slate-700 text-white focus:outline-none"
              >
                {colorMap.map(c => (
                  <option key={`b2-${c.value}`} value={c.value}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Multiplier (Band 3)</label>
              <select
                value={multiplierPower}
                onChange={e => setMultiplierPower(parseInt(e.target.value, 10))}
                className="w-full p-2 rounded bg-slate-800 border border-slate-700 text-white focus:outline-none"
              >
                {colorMap.slice(0, 8).map(c => (
                  <option key={`b3-${c.value}`} value={c.value}>
                    {c.name} (×10^{c.value})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Tolerance (Band 4)</label>
              <select
                value={toleranceVal}
                onChange={e => setToleranceVal(parseInt(e.target.value, 10))}
                className="w-full p-2 rounded bg-slate-800 border border-slate-700 text-white focus:outline-none"
              >
                <option value={5}>Gold (±5%)</option>
                <option value={10}>Silver (±10%)</option>
                <option value={1}>Brown (±1%)</option>
                <option value={2}>Red (±2%)</option>
              </select>
            </div>
          </div>
        </div>
      )}

      {/* Cheatsheet Cards */}
      <div className="space-y-6">
        {filteredCheatsheets.map(sheet => (
          <div key={sheet.id} className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
            {/* Title & Summary */}
            <div className="pb-4 mb-4 border-b border-slate-100">
              <span className="text-[11px] font-mono uppercase text-slate-400">
                {sheet.category}
              </span>
              <h3 className="text-lg font-bold text-slate-900 mt-0.5">
                {language === 'hi' ? sheet.title.hi : sheet.title.en}
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                {language === 'hi' ? sheet.summary.hi : sheet.summary.en}
              </p>
            </div>

            {/* Description */}
            <div className="text-xs text-slate-700 mb-4 leading-relaxed">
              {language === 'hi' ? sheet.content.hi : sheet.content.en}
            </div>

            {/* Formulas List if any */}
            {sheet.formulas && sheet.formulas.length > 0 && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                {sheet.formulas.map((f, fIdx) => (
                  <div key={fIdx} className="bg-slate-50 p-3.5 rounded-lg border border-slate-200 text-xs">
                    <div className="font-semibold text-slate-900 mb-1">
                      {language === 'hi' ? f.name.hi : f.name.en}
                    </div>
                    <div className="font-mono text-emerald-800 bg-emerald-50 px-2 py-1 rounded border border-emerald-200 text-[13px] font-bold mb-1.5 select-all">
                      {f.formula}
                    </div>
                    <div className="text-slate-500 text-[11px]">
                      {language === 'hi' ? f.explanation.hi : f.explanation.en}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Data Table if any */}
            {sheet.tableData && (
              <div className="overflow-x-auto rounded-lg border border-slate-200">
                <table className="min-w-full text-xs text-left">
                  <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                    <tr>
                      {sheet.tableData.headers.map((h, hIdx) => (
                        <th key={hIdx} className="px-3.5 py-2">
                          {h}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {sheet.tableData.rows.map((row, rIdx) => (
                      <tr key={rIdx} className="hover:bg-slate-50/80 font-mono">
                        {row.map((cell, cIdx) => (
                          <td key={cIdx} className="px-3.5 py-2 text-slate-800">
                            {cell}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
