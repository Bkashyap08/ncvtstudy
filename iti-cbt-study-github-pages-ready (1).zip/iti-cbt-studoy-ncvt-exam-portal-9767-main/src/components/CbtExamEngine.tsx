import React, { useState, useEffect, useMemo } from 'react';
import { Question, QuestionAttemptStatus, UserAnswerRecord, SubjectCategory, ExamResult, Language } from '../types';
import { TechnicalDiagram } from './TechnicalDiagram';
import { NCVT_CBT_GUIDELINES } from '../data/trades';

interface CbtExamEngineProps {
  questions: Question[];
  tradeName: string;
  tradeCode: string;
  year: 1 | 2;
  studentName: string;
  rollNumber: string;
  initialTimeMinutes: number;
  initialLanguage?: Language;
  onFinishExam: (result: ExamResult) => void;
  onExitExam: () => void;
}

export const CbtExamEngine: React.FC<CbtExamEngineProps> = ({
  questions,
  tradeName,
  tradeCode,
  year,
  studentName,
  rollNumber,
  initialTimeMinutes,
  initialLanguage = 'bilingual',
  onFinishExam,
  onExitExam
}) => {
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [language, setLanguage] = useState<Language>(initialLanguage);
  const [fontSizeLevel, setFontSizeLevel] = useState<'normal' | 'large' | 'xlarge'>('normal');
  const [selectedSection, setSelectedSection] = useState<string>('all');
  const [showSubmitModal, setShowSubmitModal] = useState<boolean>(false);
  const [sidebarOpenMobile, setSidebarOpenMobile] = useState<boolean>(false);

  // Time remaining in seconds
  const [secondsRemaining, setSecondsRemaining] = useState<number>(initialTimeMinutes * 60);

  // Answers and attempt status
  const [records, setRecords] = useState<{ [qId: string]: UserAnswerRecord }>(() => {
    const init: { [qId: string]: UserAnswerRecord } = {};
    questions.forEach((q, idx) => {
      init[q.id] = {
        questionId: q.id,
        selectedOption: undefined,
        status: idx === 0 ? 'not_answered' : 'not_visited',
        timeSpentSeconds: 0
      };
    });
    return init;
  });

  // Current Question
  const currentQuestion = questions[currentIndex] || questions[0];
  const currentRecord = records[currentQuestion.id] || {
    questionId: currentQuestion.id,
    selectedOption: undefined,
    status: 'not_visited',
    timeSpentSeconds: 0
  };

  // Timer countdown
  useEffect(() => {
    if (secondsRemaining <= 0) {
      handleSubmitTest();
      return;
    }

    const timer = setInterval(() => {
      setSecondsRemaining(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          handleSubmitTest();
          return 0;
        }
        return prev - 1;
      });

      // Increment time spent on current question
      setRecords(prev => {
        const qId = currentQuestion.id;
        const rec = prev[qId];
        if (!rec) return prev;
        return {
          ...prev,
          [qId]: {
            ...rec,
            timeSpentSeconds: rec.timeSpentSeconds + 1
          }
        };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [secondsRemaining, currentQuestion.id]);

  // Format time
  const formattedTime = useMemo(() => {
    const mins = Math.floor(secondsRemaining / 60);
    const secs = secondsRemaining % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }, [secondsRemaining]);

  // Section categories present in this exam
  const availableSections = useMemo(() => {
    const set = new Set<SubjectCategory>();
    questions.forEach(q => set.add(q.subjectCategory));
    return Array.from(set);
  }, [questions]);

  // Status statistics for the palette
  const statusCounts = useMemo(() => {
    const counts = {
      answered: 0,
      not_answered: 0,
      not_visited: 0,
      marked_for_review: 0,
      answered_marked: 0
    };

    Object.values(records).forEach(rec => {
      counts[rec.status]++;
    });

    return counts;
  }, [records]);

  // Option selection
  const handleSelectOption = (optionId: 'A' | 'B' | 'C' | 'D') => {
    setRecords(prev => ({
      ...prev,
      [currentQuestion.id]: {
        ...prev[currentQuestion.id],
        selectedOption: optionId
      }
    }));
  };

  // Clear response
  const handleClearResponse = () => {
    setRecords(prev => ({
      ...prev,
      [currentQuestion.id]: {
        ...prev[currentQuestion.id],
        selectedOption: undefined,
        status: 'not_answered'
      }
    }));
  };

  // Save & Next
  const handleSaveAndNext = () => {
    const hasOption = !!records[currentQuestion.id]?.selectedOption;
    setRecords(prev => ({
      ...prev,
      [currentQuestion.id]: {
        ...prev[currentQuestion.id],
        status: hasOption ? 'answered' : 'not_answered'
      }
    }));

    if (currentIndex < questions.length - 1) {
      const nextIdx = currentIndex + 1;
      // Mark next question as not_answered if it was not_visited
      setRecords(prev => {
        const nextQ = questions[nextIdx];
        if (prev[nextQ.id]?.status === 'not_visited') {
          return {
            ...prev,
            [nextQ.id]: {
              ...prev[nextQ.id],
              status: 'not_answered'
            }
          };
        }
        return prev;
      });
      setCurrentIndex(nextIdx);
    }
  };

  // Mark for review & Next
  const handleMarkForReviewAndNext = () => {
    const hasOption = !!records[currentQuestion.id]?.selectedOption;
    setRecords(prev => ({
      ...prev,
      [currentQuestion.id]: {
        ...prev[currentQuestion.id],
        status: hasOption ? 'answered_marked' : 'marked_for_review'
      }
    }));

    if (currentIndex < questions.length - 1) {
      const nextIdx = currentIndex + 1;
      setRecords(prev => {
        const nextQ = questions[nextIdx];
        if (prev[nextQ.id]?.status === 'not_visited') {
          return {
            ...prev,
            [nextQ.id]: {
              ...prev[nextQ.id],
              status: 'not_answered'
            }
          };
        }
        return prev;
      });
      setCurrentIndex(nextIdx);
    }
  };

  // Jump to specific question
  const handleJumpToQuestion = (idx: number) => {
    // If target was not_visited, change it to not_answered
    const targetQ = questions[idx];
    if (records[targetQ.id]?.status === 'not_visited') {
      setRecords(prev => ({
        ...prev,
        [targetQ.id]: {
          ...prev[targetQ.id],
          status: 'not_answered'
        }
      }));
    }
    setCurrentIndex(idx);
    setSidebarOpenMobile(false);
  };

  // Submit test
  const handleSubmitTest = () => {
    const timeTaken = initialTimeMinutes * 60 - secondsRemaining;
    let correctCount = 0;
    let attemptedCount = 0;

    const categoryMap: { [key in SubjectCategory]?: { total: number; correct: number } } = {};

    questions.forEach(q => {
      const rec = records[q.id];
      const category = q.subjectCategory;

      if (!categoryMap[category]) {
        categoryMap[category] = { total: 0, correct: 0 };
      }
      categoryMap[category]!.total += 1;

      if (rec && rec.selectedOption) {
        attemptedCount++;
        if (rec.selectedOption === q.correctOption) {
          correctCount++;
          categoryMap[category]!.correct += 1;
        }
      }
    });

    const totalQuestions = questions.length;
    const score = correctCount * 2;
    const maxScore = totalQuestions * 2;
    const percentage = totalQuestions > 0 ? (correctCount / totalQuestions) * 100 : 0;
    const isPassed = percentage >= 33; // Standard NCVT passing percentage

    const categoryBreakdown = Object.entries(categoryMap).map(([cat, data]) => ({
      category: cat as SubjectCategory,
      total: data.total,
      correct: data.correct,
      percentage: data.total > 0 ? (data.correct / data.total) * 100 : 0
    }));

    const result: ExamResult = {
      id: `exam-${Date.now()}`,
      date: new Date().toISOString(),
      tradeId: currentQuestion.tradeId as any,
      tradeName,
      year,
      mode: 'NCVT CBT Official Mock',
      totalQuestions,
      attemptedQuestions: attemptedCount,
      correctAnswers: correctCount,
      incorrectAnswers: attemptedCount - correctCount,
      score,
      maxScore,
      percentage: Math.round(percentage * 10) / 10,
      isPassed,
      timeTakenSeconds: timeTaken,
      answers: Object.values(records),
      categoryBreakdown
    };

    onFinishExam(result);
  };

  // Helper for status badge style
  const getPaletteBadgeClass = (status: QuestionAttemptStatus) => {
    switch (status) {
      case 'answered':
        return 'bg-emerald-600 text-white border-emerald-700';
      case 'not_answered':
        return 'bg-rose-600 text-white border-rose-700';
      case 'marked_for_review':
        return 'bg-purple-600 text-white border-purple-700';
      case 'answered_marked':
        return 'bg-purple-600 text-white border-purple-700 ring-2 ring-emerald-400';
      case 'not_visited':
      default:
        return 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200';
    }
  };

  // Font size multiplier
  const fontMultiplierClass =
    fontSizeLevel === 'large' ? 'text-lg leading-relaxed' : fontSizeLevel === 'xlarge' ? 'text-xl leading-loose' : 'text-base leading-normal';

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 flex flex-col select-none">
      {/* Real NCVT Top Exam Header */}
      <header className="bg-slate-900 text-white border-b border-slate-800 px-4 py-2.5">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded bg-emerald-600 flex items-center justify-center font-bold text-white text-base shadow">
              CBT
            </div>
            <div>
              <div className="text-xs uppercase tracking-wider text-slate-400">NCVT · DGT Government of India</div>
              <h1 className="text-sm md:text-base font-bold text-white tracking-tight">
                All India Trade Test (AITT) — {tradeName} (Trade Code: {tradeCode})
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-4 flex-wrap justify-end">
            {/* Font scale buttons */}
            <div className="flex items-center gap-1 bg-slate-800 p-1 rounded border border-slate-700 text-xs">
              <span className="text-slate-400 px-1 text-[11px]">Font:</span>
              <button
                onClick={() => setFontSizeLevel('normal')}
                className={`px-2 py-0.5 rounded ${fontSizeLevel === 'normal' ? 'bg-slate-600 text-white font-bold' : 'text-slate-300'}`}
                title="Normal font"
              >
                A
              </button>
              <button
                onClick={() => setFontSizeLevel('large')}
                className={`px-2 py-0.5 rounded ${fontSizeLevel === 'large' ? 'bg-slate-600 text-white font-bold' : 'text-slate-300'}`}
                title="Large font"
              >
                A+
              </button>
              <button
                onClick={() => setFontSizeLevel('xlarge')}
                className={`px-2 py-0.5 rounded ${fontSizeLevel === 'xlarge' ? 'bg-slate-600 text-white font-bold' : 'text-slate-300'}`}
                title="Extra large font"
              >
                A++
              </button>
            </div>

            {/* Language Switch */}
            <div className="flex items-center gap-1 bg-slate-800 p-1 rounded border border-slate-700 text-xs">
              <span className="text-slate-400 px-1 text-[11px]">Lang:</span>
              <button
                onClick={() => setLanguage('bilingual')}
                className={`px-2 py-0.5 rounded font-medium ${language === 'bilingual' ? 'bg-amber-600 text-white' : 'text-slate-300'}`}
              >
                Dual (EN+HI)
              </button>
              <button
                onClick={() => setLanguage('hi')}
                className={`px-2 py-0.5 rounded font-medium ${language === 'hi' ? 'bg-amber-600 text-white' : 'text-slate-300'}`}
              >
                हिन्दी
              </button>
              <button
                onClick={() => setLanguage('en')}
                className={`px-2 py-0.5 rounded font-medium ${language === 'en' ? 'bg-amber-600 text-white' : 'text-slate-300'}`}
              >
                English
              </button>
            </div>

            {/* Remaining Time Box */}
            <div className={`px-3 py-1 rounded border flex items-center gap-2 ${
              secondsRemaining < 600
                ? 'bg-rose-950/80 border-rose-600 text-rose-300 animate-pulse'
                : 'bg-slate-800 border-slate-700 text-emerald-400'
            }`}>
              <span className="text-xs text-slate-300">Time Left:</span>
              <span className="font-mono text-base font-bold tabular-nums">
                {formattedTime}
              </span>
            </div>

            {/* Exit button */}
            <button
              onClick={() => {
                if (window.confirm('Are you sure you want to pause/exit this mock examination? Your answers will not be scored.')) {
                  onExitExam();
                }
              }}
              className="text-xs text-slate-400 hover:text-white underline cursor-pointer"
            >
              Exit
            </button>
          </div>
        </div>
      </header>

      {/* Candidate Roll & Section Bar */}
      <div className="bg-white border-b border-slate-200 px-4 py-2 shadow-xs">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-slate-600">
          <div className="flex items-center gap-4 flex-wrap">
            <div>
              <span className="text-slate-400">Candidate:</span> <strong className="text-slate-800">{studentName}</strong>
            </div>
            <div>
              <span className="text-slate-400">Roll No:</span> <strong className="font-mono text-slate-800">{rollNumber}</strong>
            </div>
            <div>
              <span className="text-slate-400">Year:</span> <strong className="text-slate-800">{year}st / {year}nd Year</strong>
            </div>
          </div>

          {/* Section filter tabs */}
          <div className="flex items-center gap-1 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
            <span className="text-slate-400 mr-1 whitespace-nowrap">Section:</span>
            <button
              onClick={() => setSelectedSection('all')}
              className={`px-2.5 py-1 rounded text-xs font-medium whitespace-nowrap transition-colors ${
                selectedSection === 'all'
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              All ({questions.length})
            </button>
            {availableSections.map(cat => {
              const label =
                cat === 'trade_theory'
                  ? 'Trade Theory'
                  : cat === 'workshop_calc'
                  ? 'WCS'
                  : cat === 'engineering_drawing'
                  ? 'Eng. Drawing'
                  : 'Employability';
              const count = questions.filter(q => q.subjectCategory === cat).length;
              return (
                <button
                  key={cat}
                  onClick={() => setSelectedSection(cat)}
                  className={`px-2.5 py-1 rounded text-xs font-medium whitespace-nowrap transition-colors ${
                    selectedSection === cat
                      ? 'bg-slate-900 text-white'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {label} ({count})
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Body */}
      <div className="flex-1 max-w-7xl w-full mx-auto px-4 py-4 flex flex-col lg:flex-row gap-4 items-start">
        {/* Left Column: Question Area */}
        <div className="flex-1 w-full bg-white rounded-lg border border-slate-200 shadow-xs flex flex-col min-h-[640px]">
          {/* Question Header */}
          <div className="px-5 py-3 border-b border-slate-200 flex items-center justify-between bg-slate-50 rounded-t-lg">
            <div className="flex items-center gap-2">
              <span className="font-bold text-slate-900 text-sm md:text-base">
                Question No. {currentIndex + 1}
              </span>
              <span className="text-slate-400">of</span>
              <span className="font-medium text-slate-600 text-sm">{questions.length}</span>
              <span className="ml-2 text-xs text-slate-500 bg-white px-2 py-0.5 rounded border border-slate-200">
                {currentQuestion.module}
              </span>
            </div>

            <div className="flex items-center gap-2 text-xs font-mono">
              <span className="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 font-semibold">
                Marks: +2.0
              </span>
              <span className="text-slate-600 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                Neg: 0.0
              </span>
            </div>
          </div>

          {/* Question Body */}
          <div className="p-6 flex-1 overflow-y-auto">
            {/* English Question */}
            {(language === 'en' || language === 'bilingual') && (
              <div className={`font-semibold text-slate-900 mb-2 ${fontMultiplierClass}`}>
                {currentQuestion.question.en}
              </div>
            )}

            {/* Hindi Question */}
            {(language === 'hi' || language === 'bilingual') && (
              <div className={`font-medium text-slate-800 mb-4 font-devanagari ${
                language === 'bilingual' ? 'text-slate-700 border-t border-slate-100 pt-2 text-[0.95em]' : fontMultiplierClass
              }`}>
                {currentQuestion.question.hi}
              </div>
            )}

            {/* Technical Diagram if any */}
            {currentQuestion.diagramType && (
              <TechnicalDiagram
                type={currentQuestion.diagramType}
                caption={currentQuestion.diagramData?.caption}
                language={language}
              />
            )}

            {/* Options List */}
            <div className="mt-6 space-y-3">
              {currentQuestion.options.map(opt => {
                const isSelected = currentRecord.selectedOption === opt.id;
                return (
                  <label
                    key={opt.id}
                    onClick={() => handleSelectOption(opt.id)}
                    className={`flex items-start gap-3 p-3.5 rounded-lg border cursor-pointer transition-all ${
                      isSelected
                        ? 'border-emerald-600 bg-emerald-50/70 shadow-xs ring-1 ring-emerald-500'
                        : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center h-5 mt-0.5">
                      <input
                        type="radio"
                        name={`option-${currentQuestion.id}`}
                        checked={isSelected}
                        onChange={() => handleSelectOption(opt.id)}
                        className="w-4 h-4 text-emerald-600 focus:ring-emerald-500 border-slate-300"
                      />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-full bg-slate-200 text-slate-800 text-xs font-bold flex items-center justify-center shrink-0">
                          {opt.id}
                        </span>
                        <div className={`text-slate-900 ${fontMultiplierClass}`}>
                          {language === 'hi' ? opt.text.hi : opt.text.en}
                        </div>
                      </div>

                      {language === 'bilingual' && (
                        <div className="mt-1 text-slate-600 text-xs pl-8 font-devanagari">
                          {opt.text.hi}
                        </div>
                      )}
                    </div>
                  </label>
                );
              })}
            </div>
          </div>

          {/* Action Button Footer (Real NCVT Standard Controls) */}
          <div className="px-5 py-3.5 bg-slate-50 border-t border-slate-200 rounded-b-lg flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <button
                disabled={currentIndex === 0}
                onClick={() => setCurrentIndex(prev => Math.max(0, prev - 1))}
                className="px-3 py-2 text-xs font-semibold rounded border border-slate-300 bg-white text-slate-700 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
              >
                ← Previous
              </button>
              <button
                onClick={handleClearResponse}
                className="px-3 py-2 text-xs font-semibold rounded border border-slate-300 bg-white text-rose-700 hover:bg-rose-50 cursor-pointer"
              >
                Clear Response
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleMarkForReviewAndNext}
                className="px-3.5 py-2 text-xs font-semibold rounded bg-purple-600 hover:bg-purple-700 text-white shadow-xs cursor-pointer"
              >
                Mark for Review & Next
              </button>
              <button
                onClick={handleSaveAndNext}
                className="px-5 py-2 text-xs font-semibold rounded bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs cursor-pointer"
              >
                Save & Next →
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Question Palette Sidebar */}
        <div className="w-full lg:w-80 shrink-0 bg-white rounded-lg border border-slate-200 shadow-xs flex flex-col p-4">
          {/* Candidate Profile Widget */}
          <div className="flex items-center gap-3 pb-3 border-b border-slate-200 mb-3">
            <div className="w-12 h-12 rounded-full bg-slate-200 border border-slate-300 flex items-center justify-center font-bold text-slate-700 text-sm">
              {studentName.slice(0, 2).toUpperCase()}
            </div>
            <div className="overflow-hidden">
              <div className="font-bold text-slate-900 text-xs truncate">{studentName}</div>
              <div className="text-[11px] text-slate-500">Roll: {rollNumber}</div>
              <div className="text-[11px] text-emerald-700 font-semibold">{tradeName}</div>
            </div>
          </div>

          {/* Palette Legend */}
          <div className="text-xs font-semibold text-slate-700 mb-2">Palette Legend:</div>
          <div className="grid grid-cols-2 gap-2 text-[11px] mb-4">
            <div className="flex items-center gap-1.5">
              <span className="w-5 h-5 rounded bg-emerald-600 text-white font-bold flex items-center justify-center text-[10px]">
                {statusCounts.answered}
              </span>
              <span className="text-slate-600">Answered</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-5 h-5 rounded bg-rose-600 text-white font-bold flex items-center justify-center text-[10px]">
                {statusCounts.not_answered}
              </span>
              <span className="text-slate-600">Not Answered</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-5 h-5 rounded bg-slate-200 text-slate-700 font-bold flex items-center justify-center text-[10px] border border-slate-300">
                {statusCounts.not_visited}
              </span>
              <span className="text-slate-600">Not Visited</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-5 h-5 rounded bg-purple-600 text-white font-bold flex items-center justify-center text-[10px]">
                {statusCounts.marked_for_review}
              </span>
              <span className="text-slate-600">Marked Review</span>
            </div>
            <div className="col-span-2 flex items-center gap-1.5">
              <span className="w-5 h-5 rounded bg-purple-600 text-white font-bold flex items-center justify-center text-[10px] ring-2 ring-emerald-400">
                {statusCounts.answered_marked}
              </span>
              <span className="text-slate-600">Answered & Marked for Review</span>
            </div>
          </div>

          {/* Question Grid */}
          <div className="text-xs font-semibold text-slate-800 mb-2 flex items-center justify-between">
            <span>Question Palette:</span>
            <span className="text-[11px] text-slate-400">
              Filtered: {questions.filter(q => selectedSection === 'all' || q.subjectCategory === selectedSection).length}
            </span>
          </div>

          <div className="max-h-72 overflow-y-auto pr-1 grid grid-cols-5 gap-1.5 p-1 bg-slate-50 rounded border border-slate-200 mb-4">
            {questions.map((q, idx) => {
              if (selectedSection !== 'all' && q.subjectCategory !== selectedSection) {
                return null;
              }
              const rec = records[q.id];
              const isCurrent = idx === currentIndex;
              const badgeClass = getPaletteBadgeClass(rec?.status || 'not_visited');

              return (
                <button
                  key={q.id}
                  onClick={() => handleJumpToQuestion(idx)}
                  className={`h-8 rounded font-mono text-xs font-bold border transition-all cursor-pointer flex items-center justify-center relative ${badgeClass} ${
                    isCurrent ? 'ring-2 ring-slate-900 ring-offset-1 scale-105 z-10' : ''
                  }`}
                  title={`Question ${idx + 1}`}
                >
                  {idx + 1}
                </button>
              );
            })}
          </div>

          {/* Submit Test CTA */}
          <button
            onClick={() => setShowSubmitModal(true)}
            className="w-full py-2.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow transition-colors cursor-pointer"
          >
            Submit Examination
          </button>
        </div>
      </div>

      {/* Confirmation Modal */}
      {showSubmitModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
            <h3 className="text-lg font-bold text-slate-900 mb-2">
              Confirm Examination Submission
            </h3>
            <p className="text-xs text-slate-600 mb-4">
              Please review your question attempt summary before submitting your examination. Once submitted, you cannot modify your answers.
            </p>

            <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 space-y-2 mb-5 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-200">
                <span className="text-slate-600">Total Questions:</span>
                <span className="font-bold text-slate-900">{questions.length}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200">
                <span className="text-emerald-700 font-medium">Answered:</span>
                <span className="font-bold text-emerald-700">{statusCounts.answered}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200">
                <span className="text-rose-700 font-medium">Not Answered:</span>
                <span className="font-bold text-rose-700">{statusCounts.not_answered}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200">
                <span className="text-purple-700 font-medium">Marked for Review:</span>
                <span className="font-bold text-purple-700">{statusCounts.marked_for_review + statusCounts.answered_marked}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500">Not Visited:</span>
                <span className="font-bold text-slate-500">{statusCounts.not_visited}</span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3">
              <button
                onClick={() => setShowSubmitModal(false)}
                className="px-4 py-2 text-xs font-semibold rounded border border-slate-300 text-slate-700 hover:bg-slate-100 cursor-pointer"
              >
                Return to Test
              </button>
              <button
                onClick={handleSubmitTest}
                className="px-5 py-2 text-xs font-semibold rounded bg-emerald-600 hover:bg-emerald-700 text-white shadow cursor-pointer"
              >
                Confirm & Submit
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
