import React, { useState, useMemo } from 'react';
import { Question, TradeId, SubjectCategory, Language } from '../types';
import { TRADES, SUBJECT_CATEGORIES } from '../data/trades';
import { QUESTIONS_BANK } from '../data/questions';
import { TechnicalDiagram } from './TechnicalDiagram';
import { toggleBookmark, getBookmarkedIds } from '../utils/storage';

interface PracticeModeProps {
  initialTradeId: TradeId;
  initialYear: 1 | 2;
  onStartExamFromTrade: (tradeId: TradeId, year: 1 | 2) => void;
}

export const PracticeMode: React.FC<PracticeModeProps> = ({
  initialTradeId,
  initialYear,
  onStartExamFromTrade
}) => {
  const [selectedTrade, setSelectedTrade] = useState<TradeId>(initialTradeId);
  const [selectedYear, setSelectedYear] = useState<1 | 2>(initialYear);
  const [selectedSubject, setSelectedSubject] = useState<SubjectCategory>('trade_theory');
  const [selectedModule, setSelectedModule] = useState<string>('all');
  const [language, setLanguage] = useState<Language>('bilingual');
  const [currentIndex, setCurrentIndex] = useState<number>(0);

  // User attempts state: questionId -> selectedOption
  const [userAnswers, setUserAnswers] = useState<{ [qId: string]: 'A' | 'B' | 'C' | 'D' }>({});
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>(getBookmarkedIds());

  // Filter pool
  const filteredQuestions = useMemo(() => {
    return QUESTIONS_BANK.filter(q => {
      // Check trade
      if (selectedSubject === 'trade_theory') {
        if (q.tradeId !== selectedTrade) return false;
        if (q.year !== selectedYear) return false;
      } else if (selectedSubject === 'employability_skills') {
        if (q.subjectCategory !== 'employability_skills') return false;
      } else if (selectedSubject === 'workshop_calc' || selectedSubject === 'engineering_drawing') {
        if (q.subjectCategory !== selectedSubject) return false;
      }

      // Check module
      if (selectedModule !== 'all' && q.module !== selectedModule) {
        return false;
      }

      return true;
    });
  }, [selectedTrade, selectedYear, selectedSubject, selectedModule]);

  // Extract distinct modules for dropdown
  const availableModules = useMemo(() => {
    const set = new Set<string>();
    QUESTIONS_BANK.filter(q => {
      if (selectedSubject === 'trade_theory') {
        return q.tradeId === selectedTrade && q.year === selectedYear;
      }
      return q.subjectCategory === selectedSubject;
    }).forEach(q => set.add(q.module));
    return Array.from(set);
  }, [selectedTrade, selectedYear, selectedSubject]);

  // Safe current question
  const currentQ = filteredQuestions[currentIndex] || filteredQuestions[0];
  const selectedOption = currentQ ? userAnswers[currentQ.id] : undefined;
  const isAnswered = selectedOption !== undefined;
  const isBookmarked = currentQ ? bookmarkedIds.includes(currentQ.id) : false;

  const handleSelectOption = (optId: 'A' | 'B' | 'C' | 'D') => {
    if (!currentQ) return;
    setUserAnswers(prev => ({
      ...prev,
      [currentQ.id]: optId
    }));
  };

  const handleResetCurrent = () => {
    if (!currentQ) return;
    setUserAnswers(prev => {
      const copy = { ...prev };
      delete copy[currentQ.id];
      return copy;
    });
  };

  const handleBookmarkToggle = () => {
    if (!currentQ) return;
    toggleBookmark(currentQ.id);
    setBookmarkedIds(getBookmarkedIds());
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      {/* Header bar */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">
          Chapter-wise Practice & Study Mode
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Instant feedback learning mode based on Bharat Skills & NIMI instructional question banks.
        </p>
      </div>

      {/* Control Strip */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs mb-6 space-y-4">
        {/* Trade and Year Selector */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Trade</label>
            <select
              value={selectedTrade}
              onChange={e => {
                setSelectedTrade(e.target.value as TradeId);
                setCurrentIndex(0);
                setSelectedModule('all');
              }}
              className="w-full text-xs p-2 rounded-lg border border-slate-300 bg-white focus:ring-1 focus:ring-slate-900 focus:outline-none"
            >
              {TRADES.map(t => (
                <option key={t.id} value={t.id}>
                  {t.name.en} ({t.code})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Year</label>
            <select
              value={selectedYear}
              onChange={e => {
                setSelectedYear(parseInt(e.target.value, 10) as 1 | 2);
                setCurrentIndex(0);
                setSelectedModule('all');
              }}
              className="w-full text-xs p-2 rounded-lg border border-slate-300 bg-white focus:ring-1 focus:ring-slate-900 focus:outline-none"
            >
              <option value={1}>1st Year (First Year)</option>
              <option value={2}>2nd Year (Second Year)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Subject</label>
            <select
              value={selectedSubject}
              onChange={e => {
                setSelectedSubject(e.target.value as SubjectCategory);
                setCurrentIndex(0);
                setSelectedModule('all');
              }}
              className="w-full text-xs p-2 rounded-lg border border-slate-300 bg-white focus:ring-1 focus:ring-slate-900 focus:outline-none"
            >
              {SUBJECT_CATEGORIES.map(sub => (
                <option key={sub.id} value={sub.id}>
                  {sub.name.en}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Module / Unit</label>
            <select
              value={selectedModule}
              onChange={e => {
                setSelectedModule(e.target.value);
                setCurrentIndex(0);
              }}
              className="w-full text-xs p-2 rounded-lg border border-slate-300 bg-white focus:ring-1 focus:ring-slate-900 focus:outline-none"
            >
              <option value="all">All Modules ({filteredQuestions.length})</option>
              {availableModules.map(mod => (
                <option key={mod} value={mod}>
                  {mod}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Second row: language toggle and action */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pt-3 border-t border-slate-100">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500">Language:</span>
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-md text-xs">
              <button
                onClick={() => setLanguage('bilingual')}
                className={`px-2.5 py-1 rounded transition-colors ${
                  language === 'bilingual' ? 'bg-white text-slate-900 font-semibold shadow-xs' : 'text-slate-600'
                }`}
              >
                Dual (EN+HI)
              </button>
              <button
                onClick={() => setLanguage('hi')}
                className={`px-2.5 py-1 rounded transition-colors ${
                  language === 'hi' ? 'bg-white text-slate-900 font-semibold shadow-xs' : 'text-slate-600'
                }`}
              >
                हिन्दी
              </button>
              <button
                onClick={() => setLanguage('en')}
                className={`px-2.5 py-1 rounded transition-colors ${
                  language === 'en' ? 'bg-white text-slate-900 font-semibold shadow-xs' : 'text-slate-600'
                }`}
              >
                English
              </button>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onStartExamFromTrade(selectedTrade, selectedYear)}
              className="px-3.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
            >
              Launch Mock Test for this Trade →
            </button>
          </div>
        </div>
      </div>

      {/* Main Practice Question Card */}
      {currentQ ? (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 md:p-8">
          {/* Top Question Info */}
          <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-100">
            <div className="flex items-center gap-3">
              <span className="font-mono text-xs font-bold text-white bg-slate-900 px-2.5 py-1 rounded">
                Question {currentIndex + 1} of {filteredQuestions.length}
              </span>
              <span className="text-xs text-slate-500 font-medium">
                {currentQ.module}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleBookmarkToggle}
                className={`px-2.5 py-1 rounded text-xs font-medium flex items-center gap-1 transition-colors cursor-pointer ${
                  isBookmarked
                    ? 'text-amber-700 bg-amber-50 border border-amber-200'
                    : 'text-slate-500 hover:text-slate-800 hover:bg-slate-100'
                }`}
              >
                ★ {isBookmarked ? 'Bookmarked' : 'Bookmark'}
              </button>

              {isAnswered && (
                <button
                  onClick={handleResetCurrent}
                  className="px-2 py-1 text-xs text-slate-500 hover:text-slate-800 underline cursor-pointer"
                >
                  Reset
                </button>
              )}
            </div>
          </div>

          {/* Question Text */}
          <div className="mb-4">
            {(language === 'en' || language === 'bilingual') && (
              <h2 className="text-lg font-semibold text-slate-900 mb-2 leading-relaxed">
                {currentQ.question.en}
              </h2>
            )}
            {(language === 'hi' || language === 'bilingual') && (
              <h3 className="text-base font-normal text-slate-800 font-devanagari leading-relaxed">
                {currentQ.question.hi}
              </h3>
            )}
          </div>

          {/* Technical Diagram */}
          {currentQ.diagramType && (
            <TechnicalDiagram
              type={currentQ.diagramType}
              caption={currentQ.diagramData?.caption}
              language={language}
            />
          )}

          {/* Options */}
          <div className="space-y-3 mt-6">
            {currentQ.options.map(opt => {
              const isSelected = selectedOption === opt.id;
              const isCorrect = opt.id === currentQ.correctOption;

              let optionStyle = 'border-slate-200 bg-white hover:bg-slate-50';

              if (isAnswered) {
                if (isCorrect) {
                  optionStyle = 'border-emerald-500 bg-emerald-50/80 text-emerald-950 font-semibold ring-1 ring-emerald-500';
                } else if (isSelected && !isCorrect) {
                  optionStyle = 'border-rose-400 bg-rose-50 text-rose-950 ring-1 ring-rose-400';
                } else {
                  optionStyle = 'border-slate-200 opacity-60 bg-slate-50';
                }
              }

              return (
                <button
                  key={opt.id}
                  disabled={isAnswered}
                  onClick={() => handleSelectOption(opt.id)}
                  className={`w-full text-left p-4 rounded-lg border transition-all flex items-start gap-3 cursor-pointer ${optionStyle}`}
                >
                  <span className={`w-6 h-6 rounded-full flex items-center justify-center font-bold text-xs shrink-0 ${
                    isAnswered && isCorrect
                      ? 'bg-emerald-600 text-white'
                      : isAnswered && isSelected && !isCorrect
                      ? 'bg-rose-600 text-white'
                      : 'bg-slate-100 text-slate-800'
                  }`}>
                    {opt.id}
                  </span>

                  <div className="flex-1 text-sm">
                    <div className="font-medium text-slate-900">
                      {language === 'hi' ? opt.text.hi : opt.text.en}
                    </div>
                    {language === 'bilingual' && (
                      <div className="text-xs text-slate-600 font-devanagari mt-1">
                        {opt.text.hi}
                      </div>
                    )}
                  </div>

                  {isAnswered && isCorrect && (
                    <span className="text-xs font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded shrink-0">
                      ✓ Correct Answer
                    </span>
                  )}
                  {isAnswered && isSelected && !isCorrect && (
                    <span className="text-xs font-bold text-rose-700 bg-rose-100 px-2 py-0.5 rounded shrink-0">
                      ✗ Wrong Answer
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Explanation Box (Visible immediately upon answer) */}
          {isAnswered && (
            <div className="mt-6 p-5 rounded-lg bg-amber-50/90 border border-amber-200 text-xs text-amber-950 animate-in fade-in duration-200">
              <div className="font-bold text-sm text-amber-900 mb-1.5 flex items-center gap-2">
                <span>💡 Concept Explanation & NIMI Key:</span>
                {currentQ.source && <span className="font-normal text-xs text-amber-800">({currentQ.source})</span>}
              </div>
              {(language === 'en' || language === 'bilingual') && (
                <p className="leading-relaxed mb-2">{currentQ.explanation.en}</p>
              )}
              {(language === 'hi' || language === 'bilingual') && (
                <p className="leading-relaxed font-devanagari text-amber-900">{currentQ.explanation.hi}</p>
              )}
            </div>
          )}

          {/* Bottom Next / Prev Controls */}
          <div className="mt-8 pt-4 border-t border-slate-100 flex items-center justify-between">
            <button
              disabled={currentIndex === 0}
              onClick={() => setCurrentIndex(prev => Math.max(0, prev - 1))}
              className="px-4 py-2 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            >
              ← Previous Question
            </button>

            <div className="text-xs text-slate-500 font-mono">
              {currentIndex + 1} / {filteredQuestions.length}
            </div>

            <button
              disabled={currentIndex >= filteredQuestions.length - 1}
              onClick={() => setCurrentIndex(prev => Math.min(filteredQuestions.length - 1, prev + 1))}
              className="px-5 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold shadow-xs disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            >
              Next Question →
            </button>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
          <div className="text-slate-400 text-lg mb-2">No questions found matching this filter.</div>
          <p className="text-xs text-slate-500 mb-4">
            Try choosing "All Modules" or selecting another trade subject.
          </p>
          <button
            onClick={() => setSelectedModule('all')}
            className="px-4 py-2 text-xs font-semibold bg-slate-900 text-white rounded-lg cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      )}
    </div>
  );
};
