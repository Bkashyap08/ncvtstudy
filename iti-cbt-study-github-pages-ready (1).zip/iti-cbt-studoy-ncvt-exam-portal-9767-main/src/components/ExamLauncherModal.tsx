import React, { useState } from 'react';
import { TradeId, ExamConfig, Language } from '../types';
import { TRADES } from '../data/trades';

interface ExamLauncherModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStartExam: (config: ExamConfig, candidateInfo: { name: string; roll: string; lang: Language }) => void;
  defaultTradeId: TradeId;
  defaultYear: 1 | 2;
}

export const ExamLauncherModal: React.FC<ExamLauncherModalProps> = ({
  isOpen,
  onClose,
  onStartExam,
  defaultTradeId,
  defaultYear
}) => {
  const [tradeId, setTradeId] = useState<TradeId>(defaultTradeId);
  const [year, setYear] = useState<1 | 2>(defaultYear);
  const [mode, setMode] = useState<'full_cbt' | 'quick_mock' | 'subject_test'>('full_cbt');
  const [name, setName] = useState<string>('KUMAR A.');
  const [roll, setRoll] = useState<string>('240802310045');
  const [language, setLanguage] = useState<Language>('bilingual');

  if (!isOpen) return null;

  const handleLaunch = () => {
    let totalQuestions = 75;
    let timeMinutes = 120;

    if (mode === 'quick_mock') {
      totalQuestions = 25;
      timeMinutes = 30;
    } else if (mode === 'subject_test') {
      totalQuestions = 20;
      timeMinutes = 25;
    }

    const config: ExamConfig = {
      tradeId,
      year,
      mode,
      totalQuestions,
      timeMinutes,
      passPercentage: 33
    };

    onStartExam(config, { name, roll, lang: language });
  };

  const selectedTrade = TRADES.find(t => t.id === tradeId) || TRADES[0];

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 md:p-8 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between pb-4 border-b border-slate-200">
          <div>
            <h2 className="text-xl font-bold text-slate-900">
              Configure Mock CBT Examination
            </h2>
            <p className="text-xs text-slate-500">
              Official NCVT / DGT AITT CBT Pattern Simulation
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 text-lg leading-none cursor-pointer"
          >
            ✕
          </button>
        </div>

        <div className="space-y-4 my-5 text-xs">
          {/* Candidate Profile Info */}
          <div className="grid grid-cols-2 gap-3 bg-slate-50 p-3 rounded-lg border border-slate-200">
            <div>
              <label className="block text-slate-600 font-semibold mb-1">Candidate Name</label>
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                className="w-full p-2 bg-white rounded border border-slate-300 font-medium"
              />
            </div>
            <div>
              <label className="block text-slate-600 font-semibold mb-1">Roll / Reg. No.</label>
              <input
                type="text"
                value={roll}
                onChange={e => setRoll(e.target.value)}
                className="w-full p-2 bg-white rounded border border-slate-300 font-mono font-medium"
              />
            </div>
          </div>

          {/* Trade & Year */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Select ITI Trade</label>
              <select
                value={tradeId}
                onChange={e => setTradeId(e.target.value as TradeId)}
                className="w-full p-2.5 rounded-lg border border-slate-300 bg-white"
              >
                {TRADES.map(t => (
                  <option key={t.id} value={t.id}>
                    {t.name.en} ({t.code})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Academic Year</label>
              <select
                value={year}
                onChange={e => setYear(parseInt(e.target.value, 10) as 1 | 2)}
                className="w-full p-2.5 rounded-lg border border-slate-300 bg-white"
              >
                <option value={1}>1st Year (First Year)</option>
                {selectedTrade.durationYears === 2 && (
                  <option value={2}>2nd Year (Second Year)</option>
                )}
              </select>
            </div>
          </div>

          {/* Test Pattern Mode */}
          <div>
            <label className="block text-slate-700 font-semibold mb-1.5">Exam Pattern & Duration</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setMode('full_cbt')}
                className={`p-3 rounded-lg border text-left cursor-pointer transition-all ${
                  mode === 'full_cbt'
                    ? 'border-emerald-600 bg-emerald-50/70 text-slate-900 ring-1 ring-emerald-500'
                    : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-600'
                }`}
              >
                <div className="font-bold text-xs text-slate-900">Official Full CBT</div>
                <div className="text-[11px] text-slate-500 mt-0.5">75 Questions · 120 Mins</div>
                <div className="text-[10px] text-emerald-700 font-semibold mt-1">TT(38) + WCS(6) + ED(6) + ES(25)</div>
              </button>

              <button
                type="button"
                onClick={() => setMode('quick_mock')}
                className={`p-3 rounded-lg border text-left cursor-pointer transition-all ${
                  mode === 'quick_mock'
                    ? 'border-emerald-600 bg-emerald-50/70 text-slate-900 ring-1 ring-emerald-500'
                    : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-600'
                }`}
              >
                <div className="font-bold text-xs text-slate-900">Quick Practice Mock</div>
                <div className="text-[11px] text-slate-500 mt-0.5">25 Questions · 30 Mins</div>
                <div className="text-[10px] text-slate-600 mt-1">Rapid Revision & Drill</div>
              </button>
            </div>
          </div>

          {/* Language preference */}
          <div>
            <label className="block text-slate-700 font-semibold mb-1">Question Display Language</label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'bilingual', label: 'Bilingual (EN + हिन्दी)' },
                { id: 'hi', label: 'हिन्दी Only' },
                { id: 'en', label: 'English Only' }
              ].map(item => (
                <button
                  type="button"
                  key={item.id}
                  onClick={() => setLanguage(item.id as Language)}
                  className={`py-2 px-2 rounded-lg border text-center font-medium cursor-pointer transition-all ${
                    language === item.id
                      ? 'border-slate-900 bg-slate-900 text-white'
                      : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Modal actions */}
        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-100 cursor-pointer"
          >
            Cancel
          </button>
          <button
            onClick={handleLaunch}
            className="px-6 py-2.5 text-xs font-bold rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm cursor-pointer"
          >
            Begin CBT Exam Now →
          </button>
        </div>
      </div>
    </div>
  );
};
