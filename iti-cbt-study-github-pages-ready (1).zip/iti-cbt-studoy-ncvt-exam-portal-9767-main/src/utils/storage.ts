import { ExamResult, Language, TradeId } from '../types';

const STORAGE_KEYS = {
  EXAM_RESULTS: 'iti_cbt_exam_results',
  BOOKMARKS: 'iti_cbt_bookmarked_ids',
  SELECTED_TRADE: 'iti_cbt_selected_trade',
  SELECTED_YEAR: 'iti_cbt_selected_year',
  LANGUAGE: 'iti_cbt_preferred_lang',
  STUDENT_NAME: 'iti_cbt_student_name',
  ROLL_NUMBER: 'iti_cbt_roll_number'
};

export const getStoredResults = (): ExamResult[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.EXAM_RESULTS);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    console.error('Failed to parse exam results', e);
    return [];
  }
};

export const saveExamResult = (result: ExamResult): void => {
  try {
    const existing = getStoredResults();
    const updated = [result, ...existing].slice(0, 50); // keep last 50 tests
    localStorage.setItem(STORAGE_KEYS.EXAM_RESULTS, JSON.stringify(updated));
  } catch (e) {
    console.error('Failed to save exam result', e);
  }
};

export const getBookmarkedIds = (): string[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.BOOKMARKS);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    return [];
  }
};

export const toggleBookmark = (questionId: string): boolean => {
  try {
    const bookmarks = getBookmarkedIds();
    const index = bookmarks.indexOf(questionId);
    let updated: string[];
    let isBookmarked: boolean;
    if (index >= 0) {
      updated = bookmarks.filter(id => id !== questionId);
      isBookmarked = false;
    } else {
      updated = [...bookmarks, questionId];
      isBookmarked = true;
    }
    localStorage.setItem(STORAGE_KEYS.BOOKMARKS, JSON.stringify(updated));
    return isBookmarked;
  } catch (e) {
    return false;
  }
};

export const getStoredSettings = () => {
  return {
    tradeId: (localStorage.getItem(STORAGE_KEYS.SELECTED_TRADE) as TradeId) || 'electrician',
    year: (parseInt(localStorage.getItem(STORAGE_KEYS.SELECTED_YEAR) || '1', 10) as 1 | 2) || 1,
    language: (localStorage.getItem(STORAGE_KEYS.LANGUAGE) as Language) || 'bilingual',
    studentName: localStorage.getItem(STORAGE_KEYS.STUDENT_NAME) || 'KUMAR A.',
    rollNumber: localStorage.getItem(STORAGE_KEYS.ROLL_NUMBER) || '240802310045'
  };
};

export const saveSettings = (settings: {
  tradeId?: TradeId;
  year?: 1 | 2;
  language?: Language;
  studentName?: string;
  rollNumber?: string;
}) => {
  if (settings.tradeId) localStorage.setItem(STORAGE_KEYS.SELECTED_TRADE, settings.tradeId);
  if (settings.year) localStorage.setItem(STORAGE_KEYS.SELECTED_YEAR, settings.year.toString());
  if (settings.language) localStorage.setItem(STORAGE_KEYS.LANGUAGE, settings.language);
  if (settings.studentName) localStorage.setItem(STORAGE_KEYS.STUDENT_NAME, settings.studentName);
  if (settings.rollNumber) localStorage.setItem(STORAGE_KEYS.ROLL_NUMBER, settings.rollNumber);
};
