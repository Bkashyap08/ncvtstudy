import { Question, TradeId, SubjectCategory, ExamConfig } from '../types';
import { QUESTIONS_BANK } from '../data/questions';

export function generateExamQuestions(config: ExamConfig): Question[] {
  const { tradeId, year, mode, subjectCategory, totalQuestions } = config;

  // Filter pool
  let relevantPool = QUESTIONS_BANK.filter(q => {
    // trade matching
    const isTradeMatch = q.tradeId === tradeId || q.tradeId === 'common_all' || q.tradeId === 'common_engineering';
    if (!isTradeMatch) return false;

    // year matching (or common)
    if (q.tradeId === tradeId && q.year !== year) return false;

    // subject filter if specified
    if (subjectCategory && q.subjectCategory !== subjectCategory) return false;

    return true;
  });

  // If filtered pool is smaller than requested, fallback to any matching trade or common
  if (relevantPool.length === 0) {
    relevantPool = QUESTIONS_BANK.filter(q => q.tradeId === tradeId || q.tradeId === 'common_all');
  }

  // Shuffle pool
  const shuffled = [...relevantPool].sort(() => Math.random() - 0.5);

  if (mode === 'full_cbt') {
    // Build balanced sections according to NCVT pattern:
    // Trade Theory: 38, WCS: 6, ED: 6, ES: 25 (scaled if smaller set is selected)
    const tt = shuffled.filter(q => q.subjectCategory === 'trade_theory');
    const wcs = QUESTIONS_BANK.filter(q => q.subjectCategory === 'workshop_calc');
    const ed = QUESTIONS_BANK.filter(q => q.subjectCategory === 'engineering_drawing');
    const es = QUESTIONS_BANK.filter(q => q.subjectCategory === 'employability_skills');

    const result: Question[] = [];

    // Add TT
    const ttCount = Math.min(tt.length, Math.round(totalQuestions * 0.5));
    result.push(...tt.slice(0, ttCount));

    // Add WCS
    const wcsCount = Math.min(wcs.length, Math.max(2, Math.round(totalQuestions * 0.1)));
    result.push(...wcs.slice(0, wcsCount));

    // Add ED
    const edCount = Math.min(ed.length, Math.max(2, Math.round(totalQuestions * 0.1)));
    result.push(...ed.slice(0, edCount));

    // Add ES
    const remainingCount = totalQuestions - result.length;
    result.push(...es.slice(0, Math.min(es.length, Math.max(1, remainingCount))));

    // If still less, backfill from shuffled
    while (result.length < totalQuestions && shuffled.length > 0) {
      const nextCandidate = shuffled[result.length % shuffled.length];
      // Clone with synthetic unique id to avoid duplicate react keys in huge tests
      result.push({
        ...nextCandidate,
        id: `${nextCandidate.id}-rep-${result.length}`
      });
    }

    return result.slice(0, totalQuestions);
  }

  // Quick or subject test
  const selected: Question[] = [];
  while (selected.length < totalQuestions && shuffled.length > 0) {
    for (const q of shuffled) {
      if (selected.length >= totalQuestions) break;
      selected.push({
        ...q,
        id: selected.some(s => s.id === q.id) ? `${q.id}-dup-${selected.length}` : q.id
      });
    }
  }

  return selected.slice(0, totalQuestions);
}
