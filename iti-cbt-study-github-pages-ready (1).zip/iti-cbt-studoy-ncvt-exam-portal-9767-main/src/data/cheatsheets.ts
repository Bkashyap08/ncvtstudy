export interface CheatsheetTopic {
  id: string;
  title: { en: string; hi: string };
  category: 'electrician' | 'fitter' | 'wcs' | 'welder' | 'copa';
  summary: { en: string; hi: string };
  content: {
    en: string;
    hi: string;
  };
  formulas?: {
    name: { en: string; hi: string };
    formula: string;
    explanation: { en: string; hi: string };
  }[];
  tableData?: {
    headers: string[];
    rows: string[][];
  };
}

export const CHEATSHEETS: CheatsheetTopic[] = [
  {
    id: 'resistor_color_code',
    title: {
      en: '4 & 5 Band Resistor Color Code',
      hi: '4 व 5 बैंड रेसिस्टर कलर कोड'
    },
    category: 'electrician',
    summary: {
      en: 'Standard mnemonic "B B ROY of Great Britain had Very Good Wife" to remember digit values.',
      hi: '"B B ROY of Great Britain had Very Good Wife" सूत्र द्वारा रंग और अंकों का मान याद रखें।'
    },
    content: {
      en: 'Resistors use colored bands to indicate their resistance value and tolerance. The formula is: R = (Band 1)(Band 2) × 10^(Band 3) Ω ± Tolerance.',
      hi: 'रेसिस्टर पर रंगीन पट्टियाँ प्रतिरोध मान और टॉलरेंस दर्शाती हैं। सूत्र: R = (पहला बैंड)(दूसरा बैंड) × 10^(तीसरा बैंड) Ω ± टॉलरेंस।'
    },
    tableData: {
      headers: ['Color (रंग)', 'Digit (अंक)', 'Multiplier (गुणक)', 'Tolerance (टॉलरेंस)'],
      rows: [
        ['Black (काला)', '0', '10^0 (×1)', '-'],
        ['Brown (भूरा)', '1', '10^1 (×10)', '± 1%'],
        ['Red (लाल)', '2', '10^2 (×100)', '± 2%'],
        ['Orange (नारंगी)', '3', '10^3 (×1k)', '-'],
        ['Yellow (पीला)', '4', '10^4 (×10k)', '-'],
        ['Green (हरा)', '5', '10^5 (×100k)', '± 0.5%'],
        ['Blue (नीला)', '6', '10^6 (×1M)', '± 0.25%'],
        ['Violet (बैंगनी)', '7', '10^7 (×10M)', '± 0.1%'],
        ['Grey (धूसर)', '8', '10^8', '-'],
        ['White (सफेद)', '9', '10^9', '-'],
        ['Gold (सुनहरा)', '-', '10^-1 (×0.1)', '± 5%'],
        ['Silver (चांदी)', '-', '10^-2 (×0.01)', '± 10%'],
        ['No color (कोई रंग नहीं)', '-', '-', '± 20%']
      ]
    }
  },
  {
    id: 'vernier_micrometer_formula',
    title: {
      en: 'Vernier Caliper & Micrometer Least Counts',
      hi: 'वर्नियर कैलीपर और माइक्रोमीटर अल्पतमांक सूत्र'
    },
    category: 'fitter',
    summary: {
      en: 'Mastering reading equations, least counts, and zero error corrections.',
      hi: 'पाठ्यांक समीकरण, अल्पतमांक तथा शून्य त्रुटि (Zero Error) सुधार विधि।'
    },
    content: {
      en: 'Total Reading = Main Scale Reading (MSR) + (Coinciding Vernier Division × Least Count) ± Zero Correction.',
      hi: 'कुल पाठ्यांक = मुख्य पैमाना पाठ्यांक (MSR) + (वर्नियर संपाती भाग × अल्पतमांक) ± शून्य सुधार।'
    },
    formulas: [
      {
        name: { en: 'Vernier Caliper Least Count', hi: 'वर्नियर कैलीपर अल्पतमांक' },
        formula: 'LC = 1 MSD - 1 VSD = 1 mm - (49/50) mm = 0.02 mm',
        explanation: {
          en: '50 vernier scale divisions equal 49 main scale millimeter divisions.',
          hi: '50 वर्नियर भाग मुख्य पैमाने के 49 मिमी भागों के बराबर होते हैं।'
        }
      },
      {
        name: { en: 'Outside Micrometer Least Count', hi: 'आउटसाइड माइक्रोमीटर अल्पतमांक' },
        formula: 'LC = Pitch / Number of Thimble Div = 0.5 mm / 50 = 0.01 mm',
        explanation: {
          en: 'One complete rotation of thimble advances the spindle by 0.5 mm spindle pitch.',
          hi: 'थिम्बल का एक पूरा चक्कर स्पिंडल को 0.5 मिमी आगे बढ़ाता है।'
        }
      },
      {
        name: { en: 'Zero Error Correction Rule', hi: 'शून्य त्रुटि सुधार नियम' },
        formula: 'Corrected Reading = Observed Reading - (Zero Error with sign)',
        explanation: {
          en: 'Positive zero error is ALWAYS subtracted. Negative zero error is ALWAYS added.',
          hi: 'धनात्मक त्रुटि को हमेशा घटाया जाता है। ऋणात्मक त्रुटि को हमेशा जोड़ा जाता है।'
        }
      }
    ]
  },
  {
    id: 'ohms_law_power_wheel',
    title: {
      en: "Ohm's Law & DC Power Formulas",
      hi: 'ओम का नियम और विद्युत शक्ति सूत्र'
    },
    category: 'wcs',
    summary: {
      en: 'Formulas connecting Voltage (V), Current (I), Resistance (R), and Power (P).',
      hi: 'वोल्टेज (V), करंट (I), प्रतिरोध (R) और पावर (P) के आपसी संबंध सूत्र।'
    },
    content: {
      en: "At constant temperature, electric current in a conductor is directly proportional to applied voltage and inversely proportional to resistance.",
      hi: 'नियत तापमान पर, किसी चालक में प्रवाहित धारा उसके सिरों पर लगाए गए वोल्टेज के समानुपाती और प्रतिरोध के व्युत्क्रमानुपाती होती है।'
    },
    formulas: [
      {
        name: { en: "Ohm's Law (Voltage)", hi: 'ओम का नियम (वोल्टेज)' },
        formula: 'V = I × R (Volts)',
        explanation: { en: 'Voltage equals Current times Resistance', hi: 'वोल्टेज = करंट × प्रतिरोध' }
      },
      {
        name: { en: 'Electric Power (Watts)', hi: 'विद्युत शक्ति (वॉट्स)' },
        formula: 'P = V × I = I² × R = V² / R (Watts)',
        explanation: { en: 'Three equivalent ways to calculate electric power', hi: 'शक्ति की गणना के तीन रूप' }
      },
      {
        name: { en: 'Energy Consumed (Commercial)', hi: 'विद्युत ऊर्जा खपत (यूनिट)' },
        formula: 'Units (kWh) = (Watts × Hours) / 1000',
        explanation: { en: '1 Board of Trade Unit = 1 kWh = 3.6 × 10^6 Joules', hi: '1 यूनिट = 1 किलोवॉट घंटा = 36 लाख जूल' }
      }
    ]
  },
  {
    id: 'swg_wire_gauge_table',
    title: {
      en: 'Standard Wire Gauge (SWG) to mm Table',
      hi: 'स्टैंडर्ड वायर गेज (SWG) और मिमी तालिका'
    },
    category: 'electrician',
    summary: {
      en: 'Remember: Higher SWG number means smaller wire diameter!',
      hi: 'याद रखें: SWG संख्या जितनी अधिक होगी, तार का व्यास उतना ही कम होगा!'
    },
    content: {
      en: 'SWG is used to measure winding wire diameter and sheet metal thickness in workshops.',
      hi: 'SWG का उपयोग वर्कशॉप में वाइंडिंग तार के व्यास और शीट मेटल की मोटाई मापने के लिए किया जाता है।'
    },
    tableData: {
      headers: ['SWG No.', 'Diameter (mm)', 'Diameter (inch)', 'Current Capacity (approx)'],
      rows: [
        ['10 SWG', '3.251 mm', '0.128 in', '30 - 34 A'],
        ['12 SWG', '2.642 mm', '0.104 in', '22 - 25 A'],
        ['14 SWG', '2.032 mm', '0.080 in', '15 - 18 A'],
        ['16 SWG', '1.626 mm', '0.064 in', '10 - 12 A'],
        ['18 SWG', '1.219 mm', '0.048 in', '6 - 7 A'],
        ['20 SWG', '0.914 mm', '0.036 in', '4 - 5 A'],
        ['22 SWG', '0.711 mm', '0.028 in', '2.5 - 3 A'],
        ['24 SWG', '0.559 mm', '0.022 in', '1.8 - 2 A']
      ]
    }
  },
  {
    id: 'welding_positions_guide',
    title: {
      en: 'Welding Positions (Groove & Fillet ISO/AWS)',
      hi: 'वेल्डिंग पोजीशन (ग्रूव और फिलेट मानक)'
    },
    category: 'welder',
    summary: {
      en: '1G/1F Flat, 2G/2F Horizontal, 3G/3F Vertical, 4G/4F Overhead.',
      hi: '1G/1F फ्लैट (समतल), 2G/2F क्षैतिज, 3G/3F लंबवत, 4G/4F ओवरहेड।'
    },
    content: {
      en: 'Welding positions are designated with letters G (Groove) and F (Fillet). For pipes, 5G (horizontal fixed) and 6G (45° inclined fixed) are used.',
      hi: 'वेल्डिंग स्थितियों को G (ग्रूव) और F (फिलेट) अक्षरों से दर्शाया जाता है। पाइप वेल्डिंग में 5G और 6G (45 डिग्री झुकी निश्चित पाइप) विशेष परीक्षण हैं।'
    },
    tableData: {
      headers: ['Position Code', 'Plate Orientation', 'Welding Type', 'Difficulty'],
      rows: [
        ['1G / 1F', 'Flat (Horizontal plate)', 'Downhand welding', 'Lowest (Easiest)'],
        ['2G / 2F', 'Horizontal (Vertical plate)', 'Horizontal traverse', 'Medium'],
        ['3G / 3F', 'Vertical plate', 'Vertical Up / Down', 'High'],
        ['4G / 4F', 'Overhead (Ceiling)', 'Underneath joint', 'Very High'],
        ['5G (Pipe)', 'Horizontal pipe axis fixed', 'Vertical weld path', 'High'],
        ['6G (Pipe)', '45° inclined pipe fixed', 'All-position pipe test', 'Master / Highest']
      ]
    }
  }
];
