import { TradeInfo, SubjectCategory } from '../types';

export const TRADES: TradeInfo[] = [
  {
    id: 'electrician',
    name: {
      en: 'Electrician',
      hi: 'इलेक्ट्रीशियन'
    },
    code: '0231',
    durationYears: 2,
    iconName: 'Zap',
    color: 'amber',
    description: {
      en: 'Electrical wiring, machines, transformers, AC/DC drives, earthing, domestic & industrial installations.',
      hi: 'विद्युत वायरिंग, मशीनें, ट्रांसफार्मर, AC/DC ड्राइव, अर्थिंग, घरेलू और औद्योगिक स्थापना।'
    },
    totalModules: 14
  },
  {
    id: 'fitter',
    name: {
      en: 'Fitter',
      hi: 'फ़िटर'
    },
    code: '0227',
    durationYears: 2,
    iconName: 'Wrench',
    color: 'blue',
    description: {
      en: 'Precision marking, filing, fitting, lathe operation, gauges, assembly, hydraulics and pneumatics.',
      hi: 'सटीक मार्किंग, फाइलिंग, फिटिंग, लेथ ऑपरेशन, गेज, असेंबली, हाइड्रोलिक्स और न्यूमेटिक्स।'
    },
    totalModules: 12
  },
  {
    id: 'copa',
    name: {
      en: 'COPA (Computer Operator)',
      hi: 'कोपा (कंप्यूटर ऑपरेटर)'
    },
    code: '0242',
    durationYears: 1,
    iconName: 'Monitor',
    color: 'emerald',
    description: {
      en: 'Operating systems, Office suite, VBA programming, Web design (HTML/CSS/JS), networking & cyber security.',
      hi: 'ऑपरेटिंग सिस्टम, ऑफिस सूट, VBA प्रोग्रामिंग, वेब डिजाइनिंग, नेटवर्किंग और साइबर सुरक्षा।'
    },
    totalModules: 10
  },
  {
    id: 'electronic_mechanic',
    name: {
      en: 'Electronic Mechanic',
      hi: 'इलेक्ट्रॉनिक मैकेनिक'
    },
    code: '0219',
    durationYears: 2,
    iconName: 'Cpu',
    color: 'indigo',
    description: {
      en: 'Semiconductors, SMD soldering, audio-video systems, microcontrollers, SMPS, sensors and PLCs.',
      hi: 'सेमीकंडक्टर, SMD सोल्डरिंग, ऑडियो-वीडियो सिस्टम, माइक्रोकंट्रोलर, SMPS, सेंसर और PLC।'
    },
    totalModules: 12
  },
  {
    id: 'welder',
    name: {
      en: 'Welder',
      hi: 'वेल्डर'
    },
    code: '0245',
    durationYears: 1,
    iconName: 'Flame',
    color: 'orange',
    description: {
      en: 'Oxy-acetylene gas welding, SMAW, TIG, MIG/MAG welding, weld inspection, pipe welding & safety standards.',
      hi: 'ऑक्सी-एसिटिलीन गैस वेल्डिंग, SMAW, TIG, MIG/MAG वेल्डिंग, वेल्ड निरीक्षण और सुरक्षा मानक।'
    },
    totalModules: 8
  }
];

export const SUBJECT_CATEGORIES: {
  id: SubjectCategory;
  name: { en: string; hi: string };
  defaultQuestionCount: number;
  marksPerQuestion: number;
}[] = [
  {
    id: 'trade_theory',
    name: {
      en: 'Trade Theory (TT)',
      hi: 'ट्रेड थ्योरी (TT)'
    },
    defaultQuestionCount: 38,
    marksPerQuestion: 2
  },
  {
    id: 'workshop_calc',
    name: {
      en: 'Workshop Calculation & Science (WCS)',
      hi: 'कार्यशाला गणना और विज्ञान (WCS)'
    },
    defaultQuestionCount: 6,
    marksPerQuestion: 2
  },
  {
    id: 'engineering_drawing',
    name: {
      en: 'Engineering Drawing (ED)',
      hi: 'इंजीनियरिंग ड्राइंग (ED)'
    },
    defaultQuestionCount: 6,
    marksPerQuestion: 2
  },
  {
    id: 'employability_skills',
    name: {
      en: 'Employability Skills (ES)',
      hi: 'रोजगार कौशल (ES)'
    },
    defaultQuestionCount: 25,
    marksPerQuestion: 2
  }
];

export const NCVT_CBT_GUIDELINES = {
  totalQuestions: 75,
  totalMarks: 150,
  timeMinutes: 120,
  passingPercentage: 33,
  negativeMarking: false,
  statusLegends: [
    {
      status: 'not_visited',
      labelEn: 'Not Visited',
      labelHi: 'नहीं देखा',
      bgClass: 'bg-slate-200 text-slate-700 border-slate-300'
    },
    {
      status: 'not_answered',
      labelEn: 'Not Answered',
      labelHi: 'उत्तर नहीं दिया',
      bgClass: 'bg-rose-500 text-white border-rose-600'
    },
    {
      status: 'answered',
      labelEn: 'Answered',
      labelHi: 'उत्तर दिया',
      bgClass: 'bg-emerald-600 text-white border-emerald-700'
    },
    {
      status: 'marked_for_review',
      labelEn: 'Marked for Review',
      labelHi: 'समीक्षा के लिए चिह्नित',
      bgClass: 'bg-purple-600 text-white border-purple-700'
    },
    {
      status: 'answered_marked',
      labelEn: 'Answered & Marked for Review',
      labelHi: 'उत्तर दिया और समीक्षा हेतु',
      bgClass: 'bg-purple-600 text-white border-purple-700 ring-2 ring-emerald-400'
    }
  ]
};
