import { Question } from '../types';

export const QUESTIONS_BANK: Question[] = [
  // ==========================================
  // ELECTRICIAN TRADE
  // ==========================================
  {
    id: 'elec-001',
    tradeId: 'electrician',
    year: 1,
    subjectCategory: 'trade_theory',
    module: 'Basic Electricity & Magnetism',
    moduleHi: 'बेसिक इलेक्ट्रिसिटी और चुंबकत्व',
    question: {
      en: 'What is the unit of electrical conductance?',
      hi: 'विद्युत चालकता (Conductance) की इकाई क्या है?'
    },
    options: [
      { id: 'A', text: { en: 'Ohm', hi: 'ओम' } },
      { id: 'B', text: { en: 'Siemens (mho)', hi: 'सीमेंस (महो)' } },
      { id: 'C', text: { en: 'Henry', hi: 'हेनरी' } },
      { id: 'D', text: { en: 'Farad', hi: 'फैराड' } }
    ],
    correctOption: 'B',
    explanation: {
      en: 'Conductance (G) is the reciprocal of resistance (R = 1/G). Its SI unit is Siemens (S), previously known as mho (℧).',
      hi: 'चालकता (G) प्रतिरोध का व्युत्क्रम होती है (G = 1/R)। इसकी SI इकाई सीमेंस (S) है, जिसे पहले महो (℧) कहा जाता था।'
    },
    difficulty: 'easy',
    source: 'NIMI Electrician Sem-1 / Bharat Skills'
  },
  {
    id: 'elec-002',
    tradeId: 'electrician',
    year: 1,
    subjectCategory: 'trade_theory',
    module: 'Basic Electricity & Magnetism',
    moduleHi: 'बेसिक इलेक्ट्रिसिटी और चुंबकत्व',
    question: {
      en: 'Which rule is used to determine the direction of rotation of a DC motor?',
      hi: 'DC मोटर के घूमने की दिशा निर्धारित करने के लिए किस नियम का उपयोग किया जाता है?'
    },
    options: [
      { id: 'A', text: { en: "Fleming's Left Hand Rule", hi: 'फ्लेमिंग का बायां हाथ नियम' } },
      { id: 'B', text: { en: "Fleming's Right Hand Rule", hi: 'फ्लेमिंग का दायां हाथ नियम' } },
      { id: 'C', text: { en: "Right Hand Thumb Rule", hi: 'दाहिने हाथ के अंगूठे का नियम' } },
      { id: 'D', text: { en: "Cork Screw Rule", hi: 'कॉर्क स्क्रू नियम' } }
    ],
    correctOption: 'A',
    explanation: {
      en: "Fleming's Left Hand Rule is used for motors: Thumb indicates motion/thrust, Forefinger indicates magnetic field, and Center finger indicates current.",
      hi: "फ्लेमिंग के बाएं हाथ का नियम मोटर के लिए उपयोग किया जाता है: अंगूठा गति/बल, तर्जनी उंगली चुंबकीय क्षेत्र तथा मध्यमा उंगली करंट की दिशा दर्शाती है।"
    },
    diagramType: 'circuit',
    difficulty: 'medium',
    source: 'NIMI Electrician Sem-1 / Bharat Skills'
  },
  {
    id: 'elec-003',
    tradeId: 'electrician',
    year: 1,
    subjectCategory: 'trade_theory',
    module: 'Earthing & Safety',
    moduleHi: 'अर्थिंग और सुरक्षा',
    question: {
      en: 'What is the minimum permissible size of GI pipe used for pipe earthing as per IS specification?',
      hi: 'IS विनिर्देश के अनुसार पाइप अर्थिंग के लिए उपयोग किए जाने वाले GI पाइप का न्यूनतम स्वीकार्य व्यास क्या है?'
    },
    options: [
      { id: 'A', text: { en: '19 mm internal diameter', hi: '19 मिमी आंतरिक व्यास' } },
      { id: 'B', text: { en: '25 mm internal diameter', hi: '25 मिमी आंतरिक व्यास' } },
      { id: 'C', text: { en: '38 mm internal diameter', hi: '38 मिमी आंतरिक व्यास' } },
      { id: 'D', text: { en: '50 mm internal diameter', hi: '50 मिमी आंतरिक व्यास' } }
    ],
    correctOption: 'C',
    explanation: {
      en: 'According to IS 3043, the GI pipe for pipe earthing should have a minimum internal diameter of 38 mm and minimum length of 2.5 meters in normal soil.',
      hi: 'IS 3043 के अनुसार, पाइप अर्थिंग हेतु जस्ती लोहे (GI) के पाइप का आंतरिक व्यास कम से कम 38 मिमी और लंबाई सामान्य मिट्टी में कम से कम 2.5 मीटर होनी चाहिए।'
    },
    difficulty: 'medium',
    source: 'NIMI Electrician Sem-2 / Bharat Skills'
  },
  {
    id: 'elec-004',
    tradeId: 'electrician',
    year: 2,
    subjectCategory: 'trade_theory',
    module: 'Transformers & AC Machines',
    moduleHi: 'ट्रांसफार्मर और AC मशीनें',
    question: {
      en: 'What is the function of the breather in a power transformer?',
      hi: 'पावर ट्रांसफार्मर में ब्रीदर (Breather) का मुख्य कार्य क्या है?'
    },
    options: [
      { id: 'A', text: { en: 'To cool the transformer oil', hi: 'ट्रांसफार्मर के तेल को ठंडा करना' } },
      { id: 'B', text: { en: 'To absorb moisture from the incoming air', hi: 'अंदर आने वाली वायु से नमी को सोखना' } },
      { id: 'C', text: { en: 'To indicate oil level', hi: 'तेल का स्तर इंगित करना' } },
      { id: 'D', text: { en: 'To control transformer voltage', hi: 'ट्रांसफार्मर वोल्टेज को नियंत्रित करना' } }
    ],
    correctOption: 'B',
    explanation: {
      en: 'The breather contains Silica Gel which absorbs moisture from the air sucked into the conservator tank when transformer oil contracts upon cooling.',
      hi: 'ब्रीदर में सिलिका जेल होता है जो ट्रांसफार्मर ठंडा होने पर कंजरवेटर टैंक में प्रवेश करने वाली हवा की नमी को सोख लेता है।'
    },
    diagramType: 'transformer',
    difficulty: 'easy',
    source: 'NIMI Electrician Sem-3 / Bharat Skills'
  },
  {
    id: 'elec-005',
    tradeId: 'electrician',
    year: 2,
    subjectCategory: 'trade_theory',
    module: 'Alternators & Synchronous Motors',
    moduleHi: 'अल्टरनेटर और सिंक्रोनस मोटर',
    question: {
      en: 'What is the formula to calculate the synchronous speed (Ns) of a 3-phase alternator?',
      hi: '3-फेज अल्टरनेटर की तुल्यकालिक गति (Ns) की गणना करने का सूत्र क्या है?'
    },
    options: [
      { id: 'A', text: { en: 'Ns = (120 × f) / P', hi: 'Ns = (120 × f) / P' } },
      { id: 'B', text: { en: 'Ns = (120 × P) / f', hi: 'Ns = (120 × P) / f' } },
      { id: 'C', text: { en: 'Ns = (P × f) / 120', hi: 'Ns = (P × f) / 120' } },
      { id: 'D', text: { en: 'Ns = 60 × f / P', hi: 'Ns = 60 × f / P' } }
    ],
    correctOption: 'A',
    explanation: {
      en: 'Synchronous speed Ns = (120 × f) / P, where f is the frequency in Hertz and P is the number of poles.',
      hi: 'तुल्यकालिक गति Ns = (120 × f) / P, जहाँ f हर्ट्ज़ में आवृत्ति है और P पोल्स (ध्रुवों) की संख्या है।'
    },
    difficulty: 'easy',
    source: 'NIMI Electrician Sem-4 / Bharat Skills'
  },
  {
    id: 'elec-006',
    tradeId: 'electrician',
    year: 1,
    subjectCategory: 'trade_theory',
    module: 'Electrical Measuring Instruments',
    moduleHi: 'विद्युत मापक यंत्र',
    question: {
      en: 'Which instrument is used to test the insulation resistance of electrical cables and equipment?',
      hi: 'विद्युत केबलों और उपकरणों के इंसुलेशन प्रतिरोध (इंसुलेशन टेस्‍ट) को मापने के लिए किस यंत्र का उपयोग किया जाता है?'
    },
    options: [
      { id: 'A', text: { en: 'Multimeter', hi: 'मल्टीमीटर' } },
      { id: 'B', text: { en: 'Megger (Insulation Tester)', hi: 'मेगर (इंसुलेशन परीक्षक)' } },
      { id: 'C', text: { en: 'Wheatstone Bridge', hi: 'व्हीटस्टोन ब्रिज' } },
      { id: 'D', text: { en: 'Tong Tester', hi: 'टोंग परीक्षक' } }
    ],
    correctOption: 'B',
    explanation: {
      en: 'A Megohmmeter (Megger) generates high DC voltage (usually 500V or 1000V) to measure insulation resistance in Mega-ohms.',
      hi: 'मेगर (Megger) उच्च DC वोल्टेज उत्पन्न करता है तथा मेगा-ओम में इंसुलेशन प्रतिरोध को मापने के लिए प्रयोग किया जाता है।'
    },
    difficulty: 'medium',
    source: 'NIMI Electrician Sem-2 / Bharat Skills'
  },

  // ==========================================
  // FITTER TRADE
  // ==========================================
  {
    id: 'fit-001',
    tradeId: 'fitter',
    year: 1,
    subjectCategory: 'trade_theory',
    module: 'Precision Measuring Instruments',
    moduleHi: 'सटीक मापक उपकरण',
    question: {
      en: 'What is the least count of a standard metric vernier caliper?',
      hi: 'एक मानक मीट्रिक वर्नियर कैलीपर का अल्पतमांक (Least Count) क्या होता है?'
    },
    options: [
      { id: 'A', text: { en: '0.01 mm', hi: '0.01 मिमी' } },
      { id: 'B', text: { en: '0.02 mm', hi: '0.02 मिमी' } },
      { id: 'C', text: { en: '0.05 mm', hi: '0.05 मिमी' } },
      { id: 'D', text: { en: '0.1 mm', hi: '0.1 मिमी' } }
    ],
    correctOption: 'B',
    explanation: {
      en: 'Least Count of Vernier Caliper = 1 MSD - 1 VSD = 1 mm - (49/50) mm = 1/50 mm = 0.02 mm.',
      hi: 'वर्नियर कैलीपर का अल्पतमांक = 1 मुख्य पैमाना भाग - 1 वर्नियर पैमाना भाग = 1 - 49/50 = 0.02 मिमी।'
    },
    diagramType: 'vernier',
    difficulty: 'easy',
    source: 'NIMI Fitter Sem-1 / Bharat Skills'
  },
  {
    id: 'fit-002',
    tradeId: 'fitter',
    year: 1,
    subjectCategory: 'trade_theory',
    module: 'Precision Measuring Instruments',
    moduleHi: 'सटीक मापक उपकरण',
    question: {
      en: 'What is the least count of a standard metric outside micrometer having pitch 0.5 mm and 50 thimble divisions?',
      hi: '0.5 मिमी पिच और 50 थिम्बल प्रभागों वाले मानक मीट्रिक आउटसाइड माइक्रोमीटर का अल्पतमांक क्या है?'
    },
    options: [
      { id: 'A', text: { en: '0.001 mm', hi: '0.001 मिमी' } },
      { id: 'B', text: { en: '0.01 mm', hi: '0.01 मिमी' } },
      { id: 'C', text: { en: '0.02 mm', hi: '0.02 मिमी' } },
      { id: 'D', text: { en: '0.05 mm', hi: '0.05 मिमी' } }
    ],
    correctOption: 'B',
    explanation: {
      en: 'Least count of micrometer = Pitch / Number of thimble divisions = 0.5 mm / 50 = 0.01 mm.',
      hi: 'माइक्रोमीटर का अल्पतमांक = पिच / थिम्बल के कुल भाग = 0.5 मिमी / 50 = 0.01 मिमी।'
    },
    diagramType: 'micrometer',
    difficulty: 'easy',
    source: 'NIMI Fitter Sem-1 / Bharat Skills'
  },
  {
    id: 'fit-003',
    tradeId: 'fitter',
    year: 1,
    subjectCategory: 'trade_theory',
    module: 'Cutting Tools & Drilling',
    moduleHi: 'कटिंग टूल्स और ड्रिलिंग',
    question: {
      en: 'What is the point angle of a general-purpose twist drill for mild steel?',
      hi: 'माइल्ड स्टील के लिए सामान्य प्रयोजन वाले ट्विस्ट ड्रिल का पॉइंट कोण (बिंदु कोण) कितना होता है?'
    },
    options: [
      { id: 'A', text: { en: '90°', hi: '90°' } },
      { id: 'B', text: { en: '118°', hi: '118°' } },
      { id: 'C', text: { en: '135°', hi: '135°' } },
      { id: 'D', text: { en: '60°', hi: '60°' } }
    ],
    correctOption: 'B',
    explanation: {
      en: 'The standard point angle for general purpose drilling in mild steel is 118° with a lip clearance angle of 8° to 12°.',
      hi: 'माइल्ड स्टील में सामान्य प्रयोजन ड्रिलिंग के लिए मानक पॉइंट एंगल 118° होता है और लिप क्लीयरेंस 8° से 12° होता है।'
    },
    difficulty: 'easy',
    source: 'NIMI Fitter Sem-1 / Bharat Skills'
  },
  {
    id: 'fit-004',
    tradeId: 'fitter',
    year: 2,
    subjectCategory: 'trade_theory',
    module: 'Lathe Operations & Accessories',
    moduleHi: 'लेथ ऑपरेशन और सहायक उपकरण',
    question: {
      en: 'Which part of the lathe machine holds and rotates long slender jobs to prevent bending during turning?',
      hi: 'लेथ मशीन का कौन सा भाग टर्निंग के दौरान झुकने से बचाने के लिए लंबे और पतले जॉब को सहारा देता है?'
    },
    options: [
      { id: 'A', text: { en: 'Tailstock', hi: 'टेलस्टॉक' } },
      { id: 'B', text: { en: 'Steady Rest / Follower Rest', hi: 'स्टेडी रेस्ट / फॉलोअर रेस्ट' } },
      { id: 'C', text: { en: 'Tool Post', hi: 'टूल पोस्ट' } },
      { id: 'D', text: { en: 'Compound Rest', hi: 'कंपाउंड रेस्ट' } }
    ],
    correctOption: 'B',
    explanation: {
      en: 'A Steady Rest or Follower Rest supports long slender shafts to prevent deflection and vibration caused by tool cutting pressure.',
      hi: 'स्टेडी रेस्ट या फॉलोअर रेस्ट लंबे व पतले शाफ्ट को टूल के दबाव से झुकने तथा कंपन से बचाने के लिए अतिरिक्त सहारा प्रदान करता है।'
    },
    difficulty: 'medium',
    source: 'NIMI Fitter Sem-3 / Bharat Skills'
  },
  {
    id: 'fit-005',
    tradeId: 'fitter',
    year: 2,
    subjectCategory: 'trade_theory',
    module: 'Gauges & Limits, Fits & Tolerances',
    moduleHi: 'गेज और सीमाएं, फिट्स और टॉलरेंस',
    question: {
      en: 'Which gauge is used to check the internal diameter of cylindrical holes?',
      hi: 'बेलनाकार छिद्रों के आंतरिक व्यास की जांच के लिए किस गेज का उपयोग किया जाता है?'
    },
    options: [
      { id: 'A', text: { en: 'Snap Gauge', hi: 'स्नैप गेज' } },
      { id: 'B', text: { en: 'Plug Gauge', hi: 'प्लग गेज' } },
      { id: 'C', text: { en: 'Feeler Gauge', hi: 'फीलर गेज' } },
      { id: 'D', text: { en: 'Ring Gauge', hi: 'रिंग गेज' } }
    ],
    correctOption: 'B',
    explanation: {
      en: 'Plug Gauges (Go and No-Go) are specifically designed to check internal hole dimensions. Ring and Snap gauges check external diameters.',
      hi: 'प्लग गेज (Go और No-Go) का उपयोग आंतरिक छेदों के व्यास की जांच के लिए किया जाता है। बाहरी व्यास हेतु रिंग गेज या स्नैप गेज प्रयोग होते हैं।'
    },
    difficulty: 'easy',
    source: 'NIMI Fitter Sem-2 / Bharat Skills'
  },

  // ==========================================
  // COPA TRADE
  // ==========================================
  {
    id: 'copa-001',
    tradeId: 'copa',
    year: 1,
    subjectCategory: 'trade_theory',
    module: 'Computer Hardware & Operating Systems',
    moduleHi: 'कंप्यूटर हार्डवेयर और ऑपरेटिंग सिस्टम',
    question: {
      en: 'What is the full form of BIOS in computer systems?',
      hi: 'कंप्यूटर सिस्टम में BIOS का पूर्ण रूप (Full Form) क्या है?'
    },
    options: [
      { id: 'A', text: { en: 'Binary Input Output System', hi: 'बाइनरी इनपुट आउटपुट सिस्टम' } },
      { id: 'B', text: { en: 'Basic Input Output System', hi: 'बेसिक इनपुट आउटपुट सिस्टम' } },
      { id: 'C', text: { en: 'Base Integrated Operating System', hi: 'बेस इंटीग्रेटेड ऑपरेटिंग सिस्टम' } },
      { id: 'D', text: { en: 'Booting Internal Operation Software', hi: 'बूटिंग इंटरनल ऑपरेशन सॉफ्टवेयर' } }
    ],
    correctOption: 'B',
    explanation: {
      en: 'BIOS stands for Basic Input Output System. It is firmware stored in ROM that initializes hardware and boots the OS via POST.',
      hi: 'BIOS का अर्थ बेसिक इनपुट आउटपुट सिस्टम है। यह ROM में संग्रहीत फर्मवेयर है जो हार्डवेयर का परीक्षण (POST) करता है और OS को लोड करता है।'
    },
    difficulty: 'easy',
    source: 'NIMI COPA Sem-1 / Bharat Skills'
  },
  {
    id: 'copa-002',
    tradeId: 'copa',
    year: 1,
    subjectCategory: 'trade_theory',
    module: 'Web Technologies (HTML, CSS, JS)',
    moduleHi: 'वेब टेक्नोलॉजीज (HTML, CSS, JS)',
    question: {
      en: 'Which HTML5 tag is used to specify an independent, self-contained piece of content in a webpage?',
      hi: 'वेबपेज में स्वतंत्र, आत्म-निहित सामग्री को निर्दिष्ट करने के लिए किस HTML5 टैग का उपयोग किया जाता है?'
    },
    options: [
      { id: 'A', text: { en: '<section>', hi: '<section>' } },
      { id: 'B', text: { en: '<article>', hi: '<article>' } },
      { id: 'C', text: { en: '<aside>', hi: '<aside>' } },
      { id: 'D', text: { en: '<nav>', hi: '<nav>' } }
    ],
    correctOption: 'B',
    explanation: {
      en: 'The <article> tag specifies independent, self-contained content such as a blog post, news story, or forum post.',
      hi: '<article> टैग स्वतंत्र और आत्म-निहित सामग्री (जैसे ब्लॉग पोस्ट, समाचार लेख) को परिभाषित करने के लिए उपयोग किया जाता है।'
    },
    difficulty: 'medium',
    source: 'NIMI COPA Sem-2 / Bharat Skills'
  },
  {
    id: 'copa-003',
    tradeId: 'copa',
    year: 1,
    subjectCategory: 'trade_theory',
    module: 'Database Management & SQL',
    moduleHi: 'डेटाबेस प्रबंधन और SQL',
    question: {
      en: 'Which SQL command is classified as a Data Definition Language (DDL) command?',
      hi: 'किस SQL कमांड को डेटा डेफिनिशन लैंग्वेज (DDL) कमांड के रूप में वर्गीकृत किया गया है?'
    },
    options: [
      { id: 'A', text: { en: 'SELECT', hi: 'SELECT' } },
      { id: 'B', text: { en: 'INSERT', hi: 'INSERT' } },
      { id: 'C', text: { en: 'CREATE', hi: 'CREATE' } },
      { id: 'D', text: { en: 'UPDATE', hi: 'UPDATE' } }
    ],
    correctOption: 'C',
    explanation: {
      en: 'CREATE, ALTER, DROP, and TRUNCATE are DDL commands because they define or modify table structures. SELECT is DQL, and INSERT/UPDATE are DML.',
      hi: 'CREATE, ALTER, DROP और TRUNCATE DDL कमांड हैं क्योंकि वे टेबल संरचना को परिभाषित या बदलते हैं। SELECT DQL है तथा INSERT/UPDATE DML हैं।'
    },
    difficulty: 'medium',
    source: 'NIMI COPA Sem-2 / Bharat Skills'
  },
  {
    id: 'copa-004',
    tradeId: 'copa',
    year: 1,
    subjectCategory: 'trade_theory',
    module: 'Cyber Security & Networking',
    moduleHi: 'साइबर सुरक्षा और नेटवर्किंग',
    question: {
      en: 'What type of network attack masquerades as a trustworthy entity to steal credentials or credit card info via fraudulent email?',
      hi: 'धोखाधड़ी वाले ईमेल के माध्यम से क्रेडेंशियल या क्रेडिट कार्ड की जानकारी चुराने के लिए कौन सा साइबर हमला भरोसेमंद इकाई का रूप धारण करता है?'
    },
    options: [
      { id: 'A', text: { en: 'DDoS Attack', hi: 'DDoS हमला' } },
      { id: 'B', text: { en: 'Phishing', hi: 'फ़िशिंग (Phishing)' } },
      { id: 'C', text: { en: 'Ransomware', hi: 'रैनसमवेयर' } },
      { id: 'D', text: { en: 'Trojan Horse', hi: 'ट्रोजन हॉर्स' } }
    ],
    correctOption: 'B',
    explanation: {
      en: 'Phishing involves sending deceptive emails appearing from recognized institutions (e.g. banks) to trick victims into revealing sensitive personal data.',
      hi: 'फ़िशिंग (Phishing) में विश्वसनीय संस्थानों (जैसे बैंक) के नाम से फर्जी ईमेल भेजकर उपयोगकर्ताओं से पासवर्ड व बैंक विवरण हासिल किया जाता है।'
    },
    difficulty: 'easy',
    source: 'NIMI COPA Sem-2 / Bharat Skills'
  },

  // ==========================================
  // ELECTRONIC MECHANIC TRADE
  // ==========================================
  {
    id: 'el-001',
    tradeId: 'electronic_mechanic',
    year: 1,
    subjectCategory: 'trade_theory',
    module: 'Passive Components & Color Codes',
    moduleHi: 'पैसिव कंपोनेंट और कलर कोड',
    question: {
      en: 'What is the resistance value of a 4-band resistor with color bands: Brown, Black, Red, Gold?',
      hi: 'भूरा, काला, लाल, सुनहरा रंग बैंड वाले 4-बैंड रेसिस्टर का प्रतिरोध मान क्या है?'
    },
    options: [
      { id: 'A', text: { en: '100 Ω ± 5%', hi: '100 Ω ± 5%' } },
      { id: 'B', text: { en: '1 kΩ ± 5%', hi: '1 kΩ ± 5%' } },
      { id: 'C', text: { en: '10 kΩ ± 5%', hi: '10 kΩ ± 5%' } },
      { id: 'D', text: { en: '1 kΩ ± 10%', hi: '1 kΩ ± 10%' } }
    ],
    correctOption: 'B',
    explanation: {
      en: 'Brown = 1, Black = 0, Red = multiplier 10^2 (x100), Gold = ±5% tolerance. Value = 10 x 100 = 1000 Ω = 1 kΩ ± 5%.',
      hi: 'भूरा = 1, काला = 0, लाल = 10^2 गुणक, सुनहरा = ±5% टॉलरेंस। मान = 10 × 100 = 1000 Ω = 1 kΩ ± 5%।'
    },
    difficulty: 'medium',
    source: 'NIMI Electronic Mechanic Sem-1'
  },
  {
    id: 'el-002',
    tradeId: 'electronic_mechanic',
    year: 1,
    subjectCategory: 'trade_theory',
    module: 'Semiconductors & Diodes',
    moduleHi: 'सेमीकंडक्टर और डायोड',
    question: {
      en: 'What is the barrier potential (cut-in voltage) for a Silicon PN junction diode at room temperature?',
      hi: 'कमरे के तापमान पर सिलिकॉन PN जंक्शन डायोड का बैरियर पोटेंशियल (कट-इन वोल्टेज) कितना होता है?'
    },
    options: [
      { id: 'A', text: { en: '0.2 V to 0.3 V', hi: '0.2 V से 0.3 V' } },
      { id: 'B', text: { en: '0.6 V to 0.7 V', hi: '0.6 V से 0.7 V' } },
      { id: 'C', text: { en: '1.1 V to 1.2 V', hi: '1.1 V से 1.2 V' } },
      { id: 'D', text: { en: '0.1 V', hi: '0.1 V' } }
    ],
    correctOption: 'B',
    explanation: {
      en: 'At 25°C, Silicon diode barrier voltage is approx 0.7V, while Germanium diode barrier voltage is approx 0.3V.',
      hi: '25°C कमरे के तापमान पर सिलिकॉन डायोड का बैरियर पोटेंशियल लगभग 0.7V होता है, जबकि जर्मेनियम का लगभग 0.3V होता है।'
    },
    difficulty: 'easy',
    source: 'NIMI Electronic Mechanic Sem-1'
  },
  {
    id: 'el-003',
    tradeId: 'electronic_mechanic',
    year: 2,
    subjectCategory: 'trade_theory',
    module: 'Digital Electronics & Logic Gates',
    moduleHi: 'डिजिटल इलेक्ट्रॉनिक्स और लॉजिक गेट्स',
    question: {
      en: 'Which logic gate produces a HIGH (1) output only when both of its inputs are LOW (0)?',
      hi: 'कौन सा लॉजिक गेट केवल तभी HIGH (1) आउटपुट देता है जब उसके दोनों इनपुट LOW (0) हों?'
    },
    options: [
      { id: 'A', text: { en: 'NAND Gate', hi: 'NAND गेट' } },
      { id: 'B', text: { en: 'NOR Gate', hi: 'NOR गेट' } },
      { id: 'C', text: { en: 'XOR Gate', hi: 'XOR गेट' } },
      { id: 'D', text: { en: 'AND Gate', hi: 'AND गेट' } }
    ],
    correctOption: 'B',
    explanation: {
      en: 'NOR gate output Y = NOT(A + B). When A=0 and B=0, Y = NOT(0) = 1. For any other input combination, output is 0.',
      hi: 'NOR गेट का आउटपुट Y = NOT(A + B) होता है। जब A=0 और B=0 हो, तब Y = 1 होता है। अन्य सभी स्थितियों में आउटपुट 0 होता है।'
    },
    diagramType: 'logic_gate',
    difficulty: 'medium',
    source: 'NIMI Electronic Mechanic Sem-3'
  },

  // ==========================================
  // WELDER TRADE
  // ==========================================
  {
    id: 'weld-001',
    tradeId: 'welder',
    year: 1,
    subjectCategory: 'trade_theory',
    module: 'Oxy-Acetylene Gas Welding',
    moduleHi: 'ऑक्सी-एसिटिलीन गैस वेल्डिंग',
    question: {
      en: 'What is the ratio of Oxygen and Acetylene gases in a Neutral Flame used in oxy-acetylene welding?',
      hi: 'ऑक्सी-एसिटिलीन वेल्डिंग में उपयोग की जाने वाली न्यूट्रल ज्वाला (तटस्थ ज्वाला) में ऑक्सीजन और एसिटिलीन गैसों का अनुपात क्या होता है?'
    },
    options: [
      { id: 'A', text: { en: '1 : 1', hi: '1 : 1' } },
      { id: 'B', text: { en: '2 : 1', hi: '2 : 1' } },
      { id: 'C', text: { en: '1 : 2', hi: '1 : 2' } },
      { id: 'D', text: { en: '1.5 : 1', hi: '1.5 : 1' } }
    ],
    correctOption: 'A',
    explanation: {
      en: 'A Neutral Flame uses equal volumes of Oxygen and Acetylene (1:1 ratio) with an inner cone temperature around 3200°C.',
      hi: 'न्यूट्रल फ्लेम (Neutral Flame) में ऑक्सीजन और एसिटिलीन का अनुपात 1:1 बराबर होता है, जिसका भीतरी तापमान लगभग 3200°C होता है।'
    },
    difficulty: 'easy',
    source: 'NIMI Welder Sem-1 / Bharat Skills'
  },
  {
    id: 'weld-002',
    tradeId: 'welder',
    year: 1,
    subjectCategory: 'trade_theory',
    module: 'Arc Welding & Polarity',
    moduleHi: 'आर्क वेल्डिंग और ध्रुवता',
    question: {
      en: 'In DC Straight Polarity (DCEN), to which terminal is the welding electrode connected?',
      hi: 'DC स्ट्रेट पोलारिटी (DCEN) में वेल्डिंग इलेक्ट्रोड किस टर्मिनल से जुड़ा होता है?'
    },
    options: [
      { id: 'A', text: { en: 'Positive terminal', hi: 'धनात्मक टर्मिनल' } },
      { id: 'B', text: { en: 'Negative terminal', hi: 'ऋणात्मक टर्मिनल' } },
      { id: 'C', text: { en: 'Neutral terminal', hi: 'न्यूट्रल टर्मिनल' } },
      { id: 'D', text: { en: 'Ground earth terminal', hi: 'ग्राउंड अर्थ टर्मिनल' } }
    ],
    correctOption: 'B',
    explanation: {
      en: 'In DCEN (Direct Current Electrode Negative / Straight Polarity), electrode is connected to negative (-) and base work piece to positive (+), producing 67% heat on workpiece and 33% on electrode.',
      hi: 'DCEN (स्ट्रेट पोलारिटी) में इलेक्ट्रोड को नेगेटिव (-) और जॉब को पॉजिटिव (+) से जोड़ा जाता है, जिससे जॉब पर 67% और इलेक्ट्रोड पर 33% ऊष्मा उत्पन्न होती है।'
    },
    difficulty: 'medium',
    source: 'NIMI Welder Sem-1 / Bharat Skills'
  },
  {
    id: 'weld-003',
    tradeId: 'welder',
    year: 1,
    subjectCategory: 'trade_theory',
    module: 'TIG & MIG Welding',
    moduleHi: 'TIG और MIG वेल्डिंग',
    question: {
      en: 'Which inert gas is most commonly used as a shielding gas in TIG (GTAW) welding of stainless steel and aluminum?',
      hi: 'स्टेनलेस स्टील और एल्यूमीनियम की TIG (GTAW) वेल्डिंग में शील्डिंग गैस के रूप में आमतौर पर किस अक्रिय गैस का उपयोग किया जाता है?'
    },
    options: [
      { id: 'A', text: { en: 'Carbon Dioxide (CO2)', hi: 'कार्बन डाइऑक्साइड (CO2)' } },
      { id: 'B', text: { en: 'Pure Argon (Ar)', hi: 'शुद्ध आर्गन (Ar)' } },
      { id: 'C', text: { en: 'Oxygen (O2)', hi: 'ऑक्सीजन (O2)' } },
      { id: 'D', text: { en: 'Hydrogen (H2)', hi: 'हाइड्रोजन (H2)' } }
    ],
    correctOption: 'B',
    explanation: {
      en: 'Pure Argon gas is chemically inert, heavier than air, provides excellent arc stability, and prevents oxidation during TIG welding.',
      hi: 'शुद्ध आर्गन एक अक्रिय गैस है जो हवा से भारी होती है और TIG वेल्डिंग में वेल्ड पूल को वायुमंडलीय संदूषण से बचाती है।'
    },
    difficulty: 'medium',
    source: 'NIMI Welder Sem-1 / Bharat Skills'
  },

  // ==========================================
  // WORKSHOP CALCULATION & SCIENCE (WCS - COMMON)
  // ==========================================
  {
    id: 'wcs-001',
    tradeId: 'common_engineering',
    year: 1,
    subjectCategory: 'workshop_calc',
    module: 'Units & Measurements',
    moduleHi: 'इकाइयाँ और मापन',
    question: {
      en: 'Convert 1 inch into millimeters (mm) as per international standard:',
      hi: 'अंतर्राष्ट्रीय मानक के अनुसार 1 इंच को मिलीमीटर (मिमी) में बदलें:'
    },
    options: [
      { id: 'A', text: { en: '25.4 mm', hi: '25.4 मिमी' } },
      { id: 'B', text: { en: '2.54 mm', hi: '2.54 मिमी' } },
      { id: 'C', text: { en: '254 mm', hi: '254 मिमी' } },
      { id: 'D', text: { en: '10 mm', hi: '10 मिमी' } }
    ],
    correctOption: 'A',
    explanation: {
      en: '1 inch is exactly equal to 25.4 millimeters (or 2.54 centimeters).',
      hi: '1 इंच ठीक 25.4 मिलीमीटर (या 2.54 सेंटीमीटर) के बराबर होता है।'
    },
    difficulty: 'easy',
    source: 'NIMI WCS 1st Year / Bharat Skills'
  },
  {
    id: 'wcs-002',
    tradeId: 'common_engineering',
    year: 1,
    subjectCategory: 'workshop_calc',
    module: 'Mass, Weight & Density',
    moduleHi: 'द्रव्यमान, भार और घनत्व',
    question: {
      en: 'What is the density of a metallic cube having mass 7800 kg and volume 1 m³?',
      hi: '7800 किलोग्राम द्रव्यमान और 1 घन मीटर आयतन वाले धातु के ब्लॉक का घनत्व क्या है?'
    },
    options: [
      { id: 'A', text: { en: '780 kg/m³', hi: '780 किग्रा/मी³' } },
      { id: 'B', text: { en: '7800 kg/m³', hi: '7800 किग्रा/मी³' } },
      { id: 'C', text: { en: '78 kg/m³', hi: '78 किग्रा/मी³' } },
      { id: 'D', text: { en: '7.8 kg/m³', hi: '7.8 किग्रा/मी³' } }
    ],
    correctOption: 'B',
    explanation: {
      en: 'Density = Mass / Volume = 7800 kg / 1 m³ = 7800 kg/m³ (density of steel).',
      hi: 'घनत्व = द्रव्यमान / आयतन = 7800 किग्रा / 1 मी³ = 7800 किग्रा/मी³ (यह स्टील का सामान्य घनत्व है)।'
    },
    difficulty: 'easy',
    source: 'NIMI WCS 1st Year / Bharat Skills'
  },
  {
    id: 'wcs-003',
    tradeId: 'common_engineering',
    year: 1,
    subjectCategory: 'workshop_calc',
    module: 'Heat & Temperature',
    moduleHi: 'ऊष्मा और तापमान',
    question: {
      en: 'At what temperature are the Celsius (°C) and Fahrenheit (°F) scales equal?',
      hi: 'किस तापमान पर सेल्सियस (°C) और फारेनहाइट (°F) पैमाने का पाठ्यांक बराबर होता है?'
    },
    options: [
      { id: 'A', text: { en: '-40°', hi: '-40°' } },
      { id: 'B', text: { en: '0°', hi: '0°' } },
      { id: 'C', text: { en: '32°', hi: '32°' } },
      { id: 'D', text: { en: '-32°', hi: '-32°' } }
    ],
    correctOption: 'A',
    explanation: {
      en: 'Formula: C/5 = (F-32)/9. Letting C = F = x: 9x = 5x - 160 => 4x = -160 => x = -40°.',
      hi: 'सूत्र C/5 = (F-32)/9 के अनुसार, जब C = F = x रखा जाए तो 4x = -160, अतः x = -40° पर दोनों पैमाने बराबर होते हैं।'
    },
    difficulty: 'medium',
    source: 'NIMI WCS 1st Year / Bharat Skills'
  },
  {
    id: 'wcs-004',
    tradeId: 'common_engineering',
    year: 1,
    subjectCategory: 'workshop_calc',
    module: 'Speed, Velocity & Work',
    moduleHi: 'गति, वेग और कार्य',
    question: {
      en: 'What is the work done in lifting a weight of 500 N through a vertical height of 4 meters?',
      hi: '500 N के भार को 4 मीटर लंबवत ऊंचाई तक उठाने में किया गया कार्य क्या है?'
    },
    options: [
      { id: 'A', text: { en: '125 Joules', hi: '125 जूल' } },
      { id: 'B', text: { en: '2000 Joules', hi: '2000 जूल' } },
      { id: 'C', text: { en: '504 Joules', hi: '504 जूल' } },
      { id: 'D', text: { en: '200 Joules', hi: '200 जूल' } }
    ],
    correctOption: 'B',
    explanation: {
      en: 'Work Done = Force × Distance = 500 N × 4 m = 2000 Joules (N·m).',
      hi: 'किया गया कार्य = बल × दूरी = 500 N × 4 m = 2000 जूल (J)।'
    },
    difficulty: 'easy',
    source: 'NIMI WCS 1st Year / Bharat Skills'
  },

  // ==========================================
  // ENGINEERING DRAWING (ED - COMMON)
  // ==========================================
  {
    id: 'ed-001',
    tradeId: 'common_engineering',
    year: 1,
    subjectCategory: 'engineering_drawing',
    module: 'Drawing Standards & Scales',
    moduleHi: 'ड्राइंग मानक और पैमाने',
    question: {
      en: 'What are the trimmed dimensions of an A4 size drawing sheet according to BIS/ISO standards?',
      hi: 'BIS/ISO मानकों के अनुसार A4 आकार की ट्रिम्ड ड्राइंग शीट का माप क्या है?'
    },
    options: [
      { id: 'A', text: { en: '210 mm × 297 mm', hi: '210 मिमी × 297 मिमी' } },
      { id: 'B', text: { en: '297 mm × 420 mm', hi: '297 मिमी × 420 मिमी' } },
      { id: 'C', text: { en: '148 mm × 210 mm', hi: '148 मिमी × 210 मिमी' } },
      { id: 'D', text: { en: '420 mm × 594 mm', hi: '420 मिमी × 594 मिमी' } }
    ],
    correctOption: 'A',
    explanation: {
      en: 'A4 sheet standard trimmed size is 210 mm × 297 mm. A3 is 297 × 420 mm, and A2 is 420 × 594 mm.',
      hi: 'A4 शीट का मानक आकार 210 × 297 मिमी होता है। A3 का 297 × 420 मिमी तथा A2 का 420 × 594 मिमी होता है।'
    },
    difficulty: 'easy',
    source: 'NIMI Engineering Drawing 1st Year'
  },
  {
    id: 'ed-002',
    tradeId: 'common_engineering',
    year: 1,
    subjectCategory: 'engineering_drawing',
    module: 'Orthographic Projections',
    moduleHi: 'ऑर्थोग्राफिक प्रोजेक्शन',
    question: {
      en: 'In First Angle Projection method, where is the Top View (Plan) drawn relative to the Front View (Elevation)?',
      hi: 'प्रथम कोण प्रक्षेपण (First Angle Projection) विधि में टॉप व्यू (प्लान) फ्रंट व्यू (एलिवेशन) के किस तरफ बनाया जाता है?'
    },
    options: [
      { id: 'A', text: { en: 'Above the Front View', hi: 'फ्रंट व्यू के ऊपर' } },
      { id: 'B', text: { en: 'Below the Front View', hi: 'फ्रंट व्यू के नीचे' } },
      { id: 'C', text: { en: 'To the right of Front View', hi: 'फ्रंट व्यू के दाईं ओर' } },
      { id: 'D', text: { en: 'To the left of Front View', hi: 'फ्रंट व्यू के बाईं ओर' } }
    ],
    correctOption: 'B',
    explanation: {
      en: 'In 1st angle projection: Top view is projected onto horizontal plane below the front view. In 3rd angle projection, top view is placed above.',
      hi: 'प्रथम कोण प्रक्षेपण में टॉप व्यू फ्रंट व्यू के नीचे बनता है, जबकि तृतीय कोण प्रक्षेपण में टॉप व्यू ऊपर बनता है।'
    },
    diagramType: 'drawing_projection',
    difficulty: 'medium',
    source: 'NIMI Engineering Drawing 1st Year'
  },
  {
    id: 'ed-003',
    tradeId: 'common_engineering',
    year: 1,
    subjectCategory: 'engineering_drawing',
    module: 'Lines & Lettering',
    moduleHi: 'रेखाएं और अक्षर लेखन',
    question: {
      en: 'Which type of line is used to indicate hidden edges and outlines in engineering drawing?',
      hi: 'इंजीनियरिंग ड्राइंग में छिपे हुए किनारों और रूपरेखा को दर्शाने के लिए किस प्रकार की रेखा का उपयोग किया जाता है?'
    },
    options: [
      { id: 'A', text: { en: 'Continuous thick line', hi: 'सतत मोटी रेखा' } },
      { id: 'B', text: { en: 'Dashed line (Hidden line)', hi: 'डैशयुक्त रेखा (छिपी हुई रेखा)' } },
      { id: 'C', text: { en: 'Long dashed dotted line (Center line)', hi: 'लंबी डैश बिंदीदार रेखा (केंद्र रेखा)' } },
      { id: 'D', text: { en: 'Continuous thin wavy line', hi: 'सतत पतली लहरदार रेखा' } }
    ],
    correctOption: 'B',
    explanation: {
      en: 'Type F (Dashed line) with dashes of approx 2-3 mm and gaps of 1 mm is used to show invisible/hidden edges.',
      hi: 'डैश रेखा (Dashed line) का उपयोग छिपे हुए (invisible) किनारों को दर्शाने के लिए किया जाता है।'
    },
    difficulty: 'easy',
    source: 'NIMI Engineering Drawing 1st Year'
  },

  // ==========================================
  // EMPLOYABILITY SKILLS (ES - COMMON ALL TRADES)
  // ==========================================
  {
    id: 'es-001',
    tradeId: 'common_all',
    year: 1,
    subjectCategory: 'employability_skills',
    module: 'English & Communication Skills',
    moduleHi: 'अंग्रेजी और संचार कौशल',
    question: {
      en: 'Which of the following is considered an example of non-verbal communication?',
      hi: 'निम्नलिखित में से किसे अशाब्दिक संचार (Non-verbal communication) का उदाहरण माना जाता है?'
    },
    options: [
      { id: 'A', text: { en: 'Writing an official email', hi: 'आधिकारिक ईमेल लिखना' } },
      { id: 'B', text: { en: 'Body language, eye contact & facial expressions', hi: 'शारीरिक भाषा, आँख से संपर्क और चेहरे के भाव' } },
      { id: 'C', text: { en: 'Speaking in a group discussion', hi: 'समूह चर्चा में बोलना' } },
      { id: 'D', text: { en: 'Reading a safety manual', hi: 'सुरक्षा पुस्तिका पढ़ना' } }
    ],
    correctOption: 'B',
    explanation: {
      en: 'Non-verbal communication conveys messages without spoken or written words—using gestures, postures, eye contact, and facial expressions.',
      hi: 'अशाब्दिक संचार में शब्दों के बिना इशारों, चेहरे के भावों, आँखों के संपर्क और शारीरिक भाषा के माध्यम से संदेश संप्रेषित होता है।'
    },
    difficulty: 'easy',
    source: 'NIMI Employability Skills 2024'
  },
  {
    id: 'es-002',
    tradeId: 'common_all',
    year: 1,
    subjectCategory: 'employability_skills',
    module: 'Occupational Safety, Health & Environment',
    moduleHi: 'व्यावसायिक सुरक्षा, स्वास्थ्य और पर्यावरण',
    question: {
      en: 'Which type of fire extinguisher is specifically recommended for extinguishing Class B fires (flammable liquids like petrol, diesel, paints)?',
      hi: 'क्लास B की आग (ज्वलनशील तरल पदार्थ जैसे पेट्रोल, डीजल, पेंट) को बुझाने के लिए विशेष रूप से किस प्रकार के अग्निशामक की सिफारिश की जाती है?'
    },
    options: [
      { id: 'A', text: { en: 'Water fire extinguisher', hi: 'जल अग्निशामक (Water type)' } },
      { id: 'B', text: { en: 'Foam or Dry Powder fire extinguisher', hi: 'फोम या ड्राई पाउडर अग्निशामक' } },
      { id: 'C', text: { en: 'Soda Acid fire extinguisher', hi: 'सोडा एसिड अग्निशामक' } },
      { id: 'D', text: { en: 'Wet Chemical fire extinguisher', hi: 'वेट केमिकल अग्निशामक' } }
    ],
    correctOption: 'B',
    explanation: {
      en: 'Foam extinguishers form a blanket over flammable liquid preventing oxygen access. Water should NEVER be used on oil fires as it causes splattering.',
      hi: 'फोम या ड्राई पाउडर ज्वलनशील तरल पर ऑक्सीजन की आपूर्ति काटकर आग बुझाता है। तेल की आग पर कभी पानी नहीं डालना चाहिए।'
    },
    diagramType: 'safety_sign',
    difficulty: 'easy',
    source: 'NIMI Employability Skills 2024'
  },
  {
    id: 'es-003',
    tradeId: 'common_all',
    year: 1,
    subjectCategory: 'employability_skills',
    module: 'Entrepreneurship Skills',
    moduleHi: 'उद्यमिता कौशल',
    question: {
      en: 'In SWOT analysis used for business planning, what does the letter "W" stand for?',
      hi: 'व्यावसायिक योजना के लिए उपयोग किए जाने वाले SWOT विश्लेषण में "W" अक्षर का क्या अर्थ है?'
    },
    options: [
      { id: 'A', text: { en: 'Wealth', hi: 'वेल्थ (Wealth)' } },
      { id: 'B', text: { en: 'Weaknesses', hi: 'कमज़ोरियाँ (Weaknesses)' } },
      { id: 'C', text: { en: 'Workforce', hi: 'कार्यबल (Workforce)' } },
      { id: 'D', text: { en: 'Warranties', hi: 'वारंटी (Warranties)' } }
    ],
    correctOption: 'B',
    explanation: {
      en: 'SWOT stands for Strengths, Weaknesses, Opportunities, and Threats.',
      hi: 'SWOT का पूरा नाम Strengths (शक्तियां), Weaknesses (कमजोरियां), Opportunities (अवसर) और Threats (खतरे) है।'
    },
    difficulty: 'easy',
    source: 'NIMI Employability Skills 2024'
  },
  {
    id: 'es-004',
    tradeId: 'common_all',
    year: 1,
    subjectCategory: 'employability_skills',
    module: 'Digital Literacy & IT',
    moduleHi: 'डिजिटल साक्षरता और आईटी',
    question: {
      en: 'Which keyboard shortcut is used to copy selected files or text in Windows operating system?',
      hi: 'विंडोज ऑपरेटिंग सिस्टम में चयनित फाइलों या टेक्स्ट को कॉपी करने के लिए किस कीबोर्ड शॉर्टकट का उपयोग किया जाता है?'
    },
    options: [
      { id: 'A', text: { en: 'Ctrl + V', hi: 'Ctrl + V' } },
      { id: 'B', text: { en: 'Ctrl + C', hi: 'Ctrl + C' } },
      { id: 'C', text: { en: 'Ctrl + X', hi: 'Ctrl + X' } },
      { id: 'D', text: { en: 'Ctrl + Z', hi: 'Ctrl + Z' } }
    ],
    correctOption: 'B',
    explanation: {
      en: 'Ctrl+C copies, Ctrl+V pastes, Ctrl+X cuts, and Ctrl+Z undos the last action.',
      hi: 'Ctrl+C कॉपी करने के लिए, Ctrl+V पेस्ट करने के लिए, Ctrl+X कट करने के लिए और Ctrl+Z अनडू करने के लिए उपयोग किया जाता है।'
    },
    difficulty: 'easy',
    source: 'NIMI Employability Skills 2024'
  },
  {
    id: 'es-005',
    tradeId: 'common_all',
    year: 1,
    subjectCategory: 'employability_skills',
    module: 'Career Skills & Workplace Readiness',
    moduleHi: 'कैरियर कौशल और कार्यस्थल तत्परता',
    question: {
      en: 'What is the standard document called that summarizes your education, skills, and work experience when applying for an ITI job apprenticeship?',
      hi: 'ITI नौकरी या अप्रेंटिसशिप के लिए आवेदन करते समय आपकी शिक्षा, कौशल और कार्य अनुभव को संक्षेप में प्रस्तुत करने वाले मानक दस्तावेज़ को क्या कहा जाता है?'
    },
    options: [
      { id: 'A', text: { en: 'Invoice', hi: 'चालान (Invoice)' } },
      { id: 'B', text: { en: 'Resume / Curriculum Vitae (CV)', hi: 'बायोडाटा / रेज़्यूमे (Resume/CV)' } },
      { id: 'C', text: { en: 'Purchase Order', hi: 'खरीद आदेश (Purchase Order)' } },
      { id: 'D', text: { en: 'Bill of Materials', hi: 'सामग्री का बिल' } }
    ],
    correctOption: 'B',
    explanation: {
      en: 'A resume/CV is a structured career summary outlining contact details, academic qualifications, technical trade skills, and achievements.',
      hi: 'रेज़्यूमे या सीवी (Resume/CV) उम्मीदवार की शिक्षा, तकनीकी ट्रेड कौशल और उपलब्धियों का संक्षिप्त लिखित दस्तावेज होता है।'
    },
    difficulty: 'easy',
    source: 'NIMI Employability Skills 2024'
  }
];
