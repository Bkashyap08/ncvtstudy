# ITI CBT Study - NCVT Exam Portal

Official CBT (Computer Based Test) preparation and simulation platform for ITI students across India (Electrician, Fitter, COPA, Welder, Electronic Mechanic, Employability Skills, and Workshop Calculation & Science).

---

## 🚀 GitHub Se Kaise Run Kare (Step-by-Step Hindi & English Guide)

### तरीका 1: अपने कंप्यूटर (PC / Laptop) पर Run करना (Local Run)

अगर आपने यह प्रोजेक्ट GitHub से डाउनलोड या Clone किया है:

#### 1. आवश्यक टूल्स (Prerequisites)
- [Node.js (LTS version)](https://nodejs.org/) इंस्टॉल होना चाहिए (Node 18 या उससे नया)।
- [Git](https://git-scm.com/) इंस्टॉल होना चाहिए।

#### 2. प्रोजेक्ट को Clone करें
टर्मिनल या Command Prompt (CMD) खोलें और लिखें:
```bash
git clone https://github.com/<YOUR_USERNAME>/iti-cbt-study.git
cd iti-cbt-study
```

#### 3. Dependencies इंस्टॉल करें
```bash
npm install
```

#### 4. Development Server शुरू करें
```bash
npm run dev
```

ब्राउज़र में यह लिंक खोलें:
👉 **`http://localhost:3000`** (या टर्मिनल में दिख रहा URL)

---

### तरीका 2: GitHub Pages पर Live Website चलाना (Free Hosting)

यह प्रोजेक्ट GitHub Actions के साथ पहले से कॉन्फ़िगर है। इसे बिना किसी सर्वर के फ्री में ऑनलाइन चलाने के लिए:

1. **GitHub पर नई रिपोजिटरी बनाएं**:
   - [github.com/new](https://github.com/new) पर जाएं।
   - रिपोजिटरी का नाम रखें: `iti-cbt-study`
   - **Public** चुनें और **Create repository** पर क्लिक करें।

2. **कोड को GitHub पर Push करें**:
   अपने कंप्यूटर के प्रोजेक्ट फोल्डर में टर्मिनल में ये कमांड्स चलाएं:
   ```bash
   git init
   git add .
   git commit -m "Initial ITI CBT Study Portal commit"
   git branch -M main
   git remote add origin https://github.com/<YOUR_USERNAME>/iti-cbt-study.git
   git push -u origin main
   ```

3. **GitHub Pages चालू करें**:
   - GitHub पर अपनी रिपोजिटरी के **Settings** टैब में जाएं।
   - बाईं ओर मेनू में **Pages** पर क्लिक करें।
   - **Build and deployment** सेक्शन के अंदर **Source** में:
     - **"GitHub Actions"** सेलेक्ट करें।
   - 1-2 मिनट में GitHub Actions ऑटोमैटिकली प्रोजेक्ट को बिल्ड करके लाइव कर देगा।
   - आपकी वेबसाइट का लाइव लिंक कुछ ऐसा होगा:
     `https://<YOUR_USERNAME>.github.io/iti-cbt-study/`

---

### तरीका 3: 1-Click Free Hosting (Vercel या Netlify)

1. [Vercel](https://vercel.com) या [Netlify](https://netlify.com) पर जाएं।
2. **Continue with GitHub** करके लॉगिन करें।
3. **Import Project** पर क्लिक करके अपनी `iti-cbt-study` रिपोजिटरी चुनें।
4. **Deploy** पर क्लिक करें — 30 सेकंड में आपकी वेबसाइट हमेशा के लिए फ्री में लाइव हो जाएगी!

---

## 🛠️ Tech Stack
- **Framework**: React 19 + TypeScript + Vite
- **Styling**: Tailwind CSS
- **Questions**: NIMI / DGT / Bharat Skills official pattern
- **Features**: Dual English/Hindi mode, 75Q CBT Simulator, Real Timers, Question Palette, Technical SVG Diagrams, Resistor Color Code Calculator.
